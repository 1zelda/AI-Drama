# Security / 安全说明

English follows Chinese.

## 中文

`shortdrama-pipeline` 会调用线上生成模型，并可能处理付费 API Key、模型调用日志、生成脚本、人物图和视频文件。请把这个仓库当作“代码仓库”，不要把运行时产物或真实密钥提交进来。

### 密钥管理

真实密钥只应放在本地 `.env` 中，`.env` 已被 `.gitignore` 忽略。仓库中只保留 `.env.example` 作为配置模板。

生产环境需要的核心密钥：

```env
ARK_API_KEY=...
```

如果真实 Key 曾经出现在聊天记录、终端截图、日志、commit、issue 或 PR 里，请先去火山方舟控制台轮换密钥，再继续使用。

### 运行时产物

以下内容都属于运行时产物，不应提交到 git：

- `outputs/`、`outputs_*/`
- SQLite 数据库
- 模型调用日志
- 生成的剧本、人物图、视频、音频
- 本地 `.env`

这些路径和文件类型已经在 `.gitignore` 中忽略。

### 发布前检查

发布或推送前建议执行：

```bash
git status --short
git ls-files
git grep -n -I -E "(ark-[A-Za-z0-9_-]{12,}|Bearer[[:space:]]+[A-Za-z0-9._~+/=-]{12,}|AKLT[A-Za-z0-9%._~+/=-]{12,}|X-Tos-(Credential|Signature)=)" -- . ':!uv.lock'
git log --all -p -- . ':!uv.lock' | rg -n "(ark-[A-Za-z0-9_-]{12,}|Bearer\\s+[A-Za-z0-9._~+/=-]{12,}|AKLT[A-Za-z0-9%._~+/=-]{12,}|X-Tos-(Credential|Signature)=)"
```

预期结果：密钥扫描命令不应返回真实 Key、签名 URL 或 Authorization token。若有命中，先停止推送并清理历史。

### 报告安全问题

如果你发现仓库中包含真实凭据、敏感日志、未忽略的大体积产物或其他安全问题，请不要在公开 issue 中粘贴密钥内容。建议通过私有渠道通知维护者，并尽快轮换受影响的密钥。

## English

`shortdrama-pipeline` calls online generation models and may handle paid API credentials, model-call logs, generated scripts, character images, and video files. Treat this repository as a source-code repository. Runtime artifacts and real credentials should stay out of git.

### Secret Management

Real credentials should only live in a local `.env` file, which is ignored by git. The repository only keeps `.env.example` as a configuration template.

The required production secret is:

```env
ARK_API_KEY=...
```

If a real key ever appears in chat, screenshots, logs, commits, issues, or pull requests, rotate it in the Volcengine Ark console before continuing.

### Runtime Artifacts

The following files are runtime artifacts and should not be committed:

- `outputs/`, `outputs_*/`
- SQLite databases
- model-call logs
- generated scripts, character images, videos, and audio files
- local `.env`

These paths and file types are already covered by `.gitignore`.

### Pre-Publish Checks

Before publishing or pushing, run:

```bash
git status --short
git ls-files
git grep -n -I -E "(ark-[A-Za-z0-9_-]{12,}|Bearer[[:space:]]+[A-Za-z0-9._~+/=-]{12,}|AKLT[A-Za-z0-9%._~+/=-]{12,}|X-Tos-(Credential|Signature)=)" -- . ':!uv.lock'
git log --all -p -- . ':!uv.lock' | rg -n "(ark-[A-Za-z0-9_-]{12,}|Bearer\\s+[A-Za-z0-9._~+/=-]{12,}|AKLT[A-Za-z0-9%._~+/=-]{12,}|X-Tos-(Credential|Signature)=)"
```

Expected result: the secret-scan commands should not return real keys, signed URLs, or Authorization tokens. If they do, stop the push and clean the history first.

### Reporting Security Issues

If you find real credentials, sensitive logs, unignored large artifacts, or other security issues in the repository, do not paste the secret content into a public issue. Notify the maintainer privately and rotate any affected keys as soon as possible.
