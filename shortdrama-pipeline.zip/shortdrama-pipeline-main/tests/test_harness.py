from shortdrama_pipeline.harness import Harness, HarnessManager, ScriptQualityHarness
from shortdrama_pipeline.models import Episode, ScriptBundle, Shot


class RecordingHarness(Harness):
    def __init__(self):
        self.events = []

    def after_script(self, ctx, script):
        self.events.append(("after_script", ctx["job_id"], script["series_title"]))
        return {"报告": "剧本结构完整"}


def test_harness_manager_runs_hooks_and_collects_reports():
    harness = RecordingHarness()
    manager = HarnessManager([harness])

    reports = manager.run("after_script", {"job_id": "job_abc"}, {"series_title": "重逢"})

    assert harness.events == [("after_script", "job_abc", "重逢")]
    assert reports == [{"harness": "RecordingHarness", "result": {"报告": "剧本结构完整"}}]


def test_script_quality_harness_warns_for_shot_duration_and_dense_dialogue():
    harness = ScriptQualityHarness()
    script = ScriptBundle(
        series_title="重逢",
        series_bible="测试",
        characters=[],
        episodes=[
            Episode(
                episode_id="episode_01",
                title="第一集",
                duration_seconds=12,
                summary="测试",
                hook="测试",
                shots=[
                    Shot(
                        shot_id="shot_001",
                        duration_seconds=3,
                        scene_location="门口",
                        characters=["female_lead"],
                        visual_description="女主停在门口，抬手，回头。",
                        dialogue=["女主：我回来了。", "女主：这次不会再走。"],
                        camera="近景",
                        emotion="克制",
                    ),
                    Shot(
                        shot_id="shot_002",
                        duration_seconds=9,
                        scene_location="客厅",
                        characters=["female_lead"],
                        visual_description="女主走进房间。",
                        dialogue=[],
                        camera="中景",
                        emotion="平静",
                    ),
                ],
            )
        ],
    )

    report = harness.after_script({"job_id": "job_001"}, script)

    assert report.job_id == "job_001"
    assert report.overall_score is not None
    assert any(issue.title == "shot_duration_out_of_range" for issue in report.shot_issues)
    assert any(issue.title == "dialogue_too_dense" for issue in report.shot_issues)
    assert "episode_01" not in report.episode_warnings


def test_script_quality_harness_warns_for_shot_overload():
    harness = ScriptQualityHarness()
    script = ScriptBundle(
        series_title="重逢",
        series_bible="测试",
        characters=[],
        episodes=[
            Episode(
                episode_id="episode_01",
                title="第一集",
                duration_seconds=8,
                summary="测试",
                hook="测试",
                shots=[
                    Shot(
                        shot_id="shot_001",
                        duration_seconds=8,
                        scene_location="楼道",
                        characters=["a", "b", "c", "d"],
                        visual_description="四人同时冲出电梯、对视、争吵、拉扯、转身、追赶。",
                        dialogue=["众人：站住。"],
                        camera="远景/中景/近景/推镜",
                        emotion="混乱",
                    )
                ],
            )
        ],
    )

    report = harness.after_script({"job_id": "job_002"}, script)

    overload_issue = next(issue for issue in report.shot_issues if issue.title == "shot_overload")
    assert overload_issue.shot_id == "shot_001"
    assert overload_issue.level == "warning"


def test_script_quality_harness_warns_when_episode_duration_gap_is_moderate():
    harness = ScriptQualityHarness()
    script = ScriptBundle(
        series_title="重逢",
        series_bible="测试",
        characters=[],
        episodes=[
            Episode(
                episode_id="episode_01",
                title="第一集",
                duration_seconds=20,
                summary="测试",
                hook="测试",
                shots=[
                    Shot(
                        shot_id="shot_001",
                        duration_seconds=8,
                        scene_location="门口",
                        characters=["female_lead"],
                        visual_description="女主停下。",
                        dialogue=[],
                        camera="近景",
                        emotion="平静",
                    ),
                    Shot(
                        shot_id="shot_002",
                        duration_seconds=9,
                        scene_location="客厅",
                        characters=["female_lead"],
                        visual_description="女主走进客厅。",
                        dialogue=[],
                        camera="中景",
                        emotion="平静",
                    ),
                ],
            )
        ],
    )

    report = harness.after_script({"job_id": "job_003"}, script)

    warnings = report.episode_warnings["episode_01"]
    assert len(warnings) == 1
    assert "warning" in warnings[0]


def test_script_quality_harness_uses_high_warning_for_large_episode_duration_gap():
    harness = ScriptQualityHarness()
    script = ScriptBundle(
        series_title="重逢",
        series_bible="测试",
        characters=[],
        episodes=[
            Episode(
                episode_id="episode_01",
                title="第一集",
                duration_seconds=30,
                summary="测试",
                hook="测试",
                shots=[
                    Shot(
                        shot_id="shot_001",
                        duration_seconds=8,
                        scene_location="门口",
                        characters=["female_lead"],
                        visual_description="女主停下。",
                        dialogue=[],
                        camera="近景",
                        emotion="平静",
                    ),
                    Shot(
                        shot_id="shot_002",
                        duration_seconds=8,
                        scene_location="客厅",
                        characters=["female_lead"],
                        visual_description="女主走进客厅。",
                        dialogue=[],
                        camera="中景",
                        emotion="平静",
                    ),
                ],
            )
        ],
    )

    report = harness.after_script({"job_id": "job_004"}, script)

    warnings = report.episode_warnings["episode_01"]
    assert len(warnings) == 1
    assert "high_warning" in warnings[0]
