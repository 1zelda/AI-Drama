from shortdrama_pipeline.models import CharacterProfile, Shot
from shortdrama_pipeline.prompts import (
    build_character_prompt,
    build_script_prompt,
    build_seedance_prompt,
)


def test_script_prompt_is_chinese_first():
    prompt = build_script_prompt(
        topic="保洁阿姨真实身份是首富千金",
        duration_seconds=90,
        episode_count=3,
        ratio="9:16",
        style="都市情感，强反转",
        notes="每集结尾要有钩子",
    )

    assert "请用中文生成" in prompt
    assert "严格 JSON" in prompt
    assert "保洁阿姨" in prompt
    assert "每个 shot 的 duration_seconds 必须大于等于 4 且小于等于 10" in prompt
    assert "每个 shot 只表达一个核心动作或一个核心情绪推进" in prompt
    assert "每个 shot 最多一条关键对白" in prompt
    assert "dialogue 允许为空" in prompt
    assert "相邻 shot 必须自然承接" in prompt


def test_character_prompt_is_chinese():
    profile = CharacterProfile(
        character_id="female_lead",
        name="苏清",
        role="女主",
        age_range="25-30",
        appearance="黑色长发，五官清冷",
        personality="坚韧，克制",
        costume_style="简洁都市通勤风",
        voice_style="清晰坚定",
        consistency_prompt="保持相同脸型和发型",
    )

    prompt = build_character_prompt(profile)

    assert "中文短剧主体人物定妆照" in prompt
    assert "苏清" in prompt
    assert "简洁都市通勤风" in prompt


def test_seedance_prompt_is_simplified_and_chinese():
    shot = Shot(
        shot_id="shot_001",
        duration_seconds=8,
        scene_location="酒店门口",
        characters=["female_lead", "male_lead"],
        visual_description="女主冒雨走出酒店，男主从车里追出来。",
        dialogue=["男主：你听我解释。", "女主：解释已经太晚了。"],
        camera="手持跟拍，雨水打在镜头边缘。",
        emotion="决绝、心碎",
    )

    prompt = build_seedance_prompt(
        series_title="雨夜重逢",
        episode_number=1,
        shot_number=1,
        shot=shot,
        style="竖屏短剧，真实影视感",
    )

    assert "请用中文生成短剧镜头视频提示词" in prompt
    assert "核心动作：" in prompt
    assert "主情绪：" in prompt
    assert "可选关键台词：" in prompt
    assert "主镜头语言：" in prompt
    assert "场景地点：" in prompt
    assert "人物一致性：" in prompt
    assert "解释已经太晚了" in prompt
    assert "男主：你听我解释。 / 女主：解释已经太晚了。" in prompt
    assert "镜头内容：" not in prompt
    assert "情绪指导：" not in prompt
    assert "镜头运动：" not in prompt
    assert "主体人物一致性要求：" not in prompt


def test_seedance_prompt_keeps_dialogue_optional():
    shot = Shot(
        shot_id="shot_002",
        duration_seconds=6,
        scene_location="医院走廊",
        characters=["female_lead"],
        visual_description="女主扶墙站稳，强忍眼泪看向急救室门口。",
        dialogue=[],
        camera="近景定机，轻微推进。",
        emotion="压抑、害怕",
    )

    prompt = build_seedance_prompt(
        series_title="暗夜回声",
        episode_number=2,
        shot_number=3,
        shot=shot,
        style="竖屏短剧，真实影视感",
    )

    assert "可选关键台词：无，可用动作和表情推进。" in prompt
    assert "女主扶墙站稳，强忍眼泪看向急救室门口。" in prompt
    assert "\n- " not in prompt
