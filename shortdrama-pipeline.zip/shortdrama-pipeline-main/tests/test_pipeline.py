import json

import pytest

from shortdrama_pipeline.models import CharacterProfile, Episode, JobCreate, ScriptBundle, Shot, VideoResult
from shortdrama_pipeline.providers import FakeImageProvider, FakeScriptProvider, FakeVideoProvider


from shortdrama_pipeline.harness import Harness, HarnessManager
from shortdrama_pipeline.logging import ModelCallLogger, PipelineEventLogger
from shortdrama_pipeline.models import JobStatus
from shortdrama_pipeline.pipeline import PipelineRunner
from shortdrama_pipeline.storage import ArtifactStore, JobStore, ProjectStore


def make_runner(output_dir):
    artifact_store = ArtifactStore(output_dir)
    job_store = JobStore(output_dir / "jobs.sqlite3")
    project_store = ProjectStore(output_dir / "jobs.sqlite3")
    pipeline_logger = PipelineEventLogger(artifact_store)
    model_logger = ModelCallLogger(artifact_store)
    return PipelineRunner(
        artifact_store=artifact_store,
        job_store=job_store,
        project_store=project_store,
        script_provider=FakeScriptProvider(model_logger=model_logger),
        image_provider=FakeImageProvider(output_dir, model_logger=model_logger),
        video_provider=FakeVideoProvider(output_dir, model_logger=model_logger),
        harness_manager=HarnessManager([]),
        pipeline_logger=pipeline_logger,
        model_logger=model_logger,
    )


class FlakyScriptProvider:
    def __init__(self):
        self.calls = 0

    def generate_script(self, job_id: str, request: JobCreate) -> ScriptBundle:
        self.calls += 1
        if self.calls == 1:
            raise ValueError("坏 JSON")
        return FakeScriptProvider().generate_script(job_id, request)


class LongShotScriptProvider:
    def generate_script(self, job_id: str, request: JobCreate) -> ScriptBundle:
        profile = CharacterProfile(
            character_id="female_lead",
            name="林晚",
            role="女主",
            age_range="25-30",
            appearance="黑色长发",
            personality="坚韧",
            costume_style="白衬衫",
            voice_style="坚定",
            consistency_prompt="保持相同五官",
        )
        episode = Episode(
            episode_id="episode_01",
            title="重逢",
            duration_seconds=21,
            summary="长镜头测试",
            hook="测试拆分",
            shots=[
                Shot(
                    shot_id="shot_001",
                    duration_seconds=21,
                    scene_location="客厅",
                    characters=["female_lead"],
                    visual_description="女主走向镜头。",
                    dialogue=["女主：我要重新开始。"],
                    camera="中景推进",
                    emotion="坚定",
                )
            ],
        )
        return ScriptBundle(
            series_title=request.topic,
            series_bible="长镜头测试剧本",
            characters=[profile],
            episodes=[episode],
        )


class RecordingVideoProvider:
    def __init__(self, output_dir):
        self.output_dir = output_dir
        self.durations: list[int] = []

    def generate_shot_video(self, job_id: str, episode_id: str, shot: Shot, output_dir: str | None = None) -> VideoResult:
        from pathlib import Path

        self.durations.append(shot.duration_seconds)
        video_root = Path(output_dir)
        video_dir = video_root / "videos" / episode_id
        video_dir.mkdir(parents=True, exist_ok=True)
        video_path = video_dir / f"{shot.shot_id}.mp4"
        video_path.write_bytes(b"video")
        return VideoResult(
            episode_id=episode_id,
            shot_id=shot.shot_id,
            task_id=f"task_{shot.shot_id}",
            video_path=str(video_path),
        )


class ShortShotScriptProvider:
    def generate_script(self, job_id: str, request: JobCreate) -> ScriptBundle:
        profile = CharacterProfile(
            character_id="female_lead",
            name="林晚",
            role="女主",
            age_range="25-30",
            appearance="黑色长发",
            personality="坚韧",
            costume_style="白衬衫",
            voice_style="坚定",
            consistency_prompt="保持相同五官",
        )
        episode = Episode(
            episode_id="episode_01",
            title="短镜头测试",
            duration_seconds=12,
            summary="过短镜头测试",
            hook="测试合并",
            shots=[
                Shot(
                    shot_id="shot_001",
                    duration_seconds=3,
                    scene_location="门口",
                    characters=["female_lead"],
                    visual_description="女主站在门口。",
                    dialogue=[],
                    camera="近景",
                    emotion="平静",
                ),
                Shot(
                    shot_id="shot_002",
                    duration_seconds=4,
                    scene_location="走廊",
                    characters=["female_lead"],
                    visual_description="女主往前走。",
                    dialogue=["女主：我来了。"],
                    camera="跟拍",
                    emotion="坚定",
                ),
                Shot(
                    shot_id="shot_003",
                    duration_seconds=2,
                    scene_location="房间",
                    characters=["female_lead"],
                    visual_description="女主停下脚步。",
                    dialogue=[],
                    camera="特写",
                    emotion="警觉",
                ),
            ],
        )
        return ScriptBundle(
            series_title=request.topic,
            series_bible="短镜头测试剧本",
            characters=[profile],
            episodes=[episode],
        )


class WarningHeavyScriptProvider:
    def generate_script(self, job_id: str, request: JobCreate) -> ScriptBundle:
        profile = CharacterProfile(
            character_id="female_lead",
            name="林晚",
            role="女主",
            age_range="25-30",
            appearance="黑色长发",
            personality="坚韧",
            costume_style="白衬衫",
            voice_style="坚定",
            consistency_prompt="保持相同五官",
        )
        episode = Episode(
            episode_id="episode_01",
            title="质量预警测试",
            duration_seconds=20,
            summary="用于验证脚本质检报告",
            hook="测试 warning 不阻塞",
            shots=[
                Shot(
                    shot_id="shot_001",
                    duration_seconds=12,
                    scene_location="天台",
                    characters=["female_lead"],
                    visual_description="林晚冲向门口，随后转身、推门、跑向楼梯，然后继续追向出口。",
                    dialogue=["林晚：我不会认输。", "林晚：这次换我赢。"],
                    camera="远景/中景/近景/特写",
                    emotion="坚定",
                )
            ],
        )
        return ScriptBundle(
            series_title=request.topic,
            series_bible="质量预警测试剧本",
            characters=[profile],
            episodes=[episode],
        )


class FailingVideoProvider:
    def generate_shot_video(self, job_id: str, episode_id: str, shot: Shot, output_dir: str | None = None) -> VideoResult:
        raise RuntimeError("Seedance 创建任务失败：duration 超限")


class ScriptReviewArtifactHarness(Harness):
    def __init__(self, artifact_store):
        self.artifact_store = artifact_store
        self.before_review_report = None

    def before_script_review(self, ctx, script):
        self.before_review_report = self.artifact_store.read_json(ctx["job_id"], "harness/script_quality_report.json")

        return None


def test_fake_script_provider_returns_chinese_script():
    provider = FakeScriptProvider()
    script = provider.generate_script(
        "job_abc",
        JobCreate(topic="替嫁新娘逆袭", duration_seconds=60, episode_count=1)
    )

    assert script.series_title == "替嫁新娘逆袭"
    assert script.characters[0].name == "林晚"
    assert "中文短剧测试剧本" in script.series_bible


def test_fake_image_provider_writes_character_image(output_dir):
    provider = FakeImageProvider(output_dir)
    profile = CharacterProfile(
        character_id="female_lead",
        name="林晚",
        role="女主",
        age_range="25-30",
        appearance="黑色长发",
        personality="坚韧",
        costume_style="白衬衫",
        voice_style="坚定",
        consistency_prompt="保持相同五官",
    )

    image = provider.generate_character_image("job_abc", profile, str(output_dir / "job_abc" / "characters" / "female_lead"))

    assert image.character_id == "female_lead"
    assert image.prompt.startswith("请生成中文短剧主体人物定妆照")
    assert image.approved_url is not None


def test_fake_video_provider_writes_shot_video(output_dir):
    provider = FakeVideoProvider(output_dir)
    shot = Shot(
        shot_id="shot_001",
        duration_seconds=8,
        scene_location="咖啡馆",
        characters=["female_lead"],
        visual_description="女主独自坐在窗边。",
        dialogue=["女主：这一次，我不会再退让。"],
        camera="中景固定镜头",
        emotion="坚定",
        seedance_prompt="中文镜头 Prompt",
    )

    result = provider.generate_shot_video("job_abc", "episode_01", shot)

    assert result.video_path.endswith("shot_001.mp4")
    assert result.task_id.startswith("fake_seedance_")


def test_pipeline_creates_job_and_stops_at_script_review(output_dir):
    runner = make_runner(output_dir)
    job = runner.create_job(JobCreate(topic="替嫁新娘逆袭", duration_seconds=60, episode_count=1))

    assert job.status == JobStatus.SCRIPT_REVIEW_PENDING
    assert job.project_id is not None
    assert (output_dir / "projects" / job.project_id / "runs" / job.job_id / "script" / "reviewed_script.json").exists()
    assert not (output_dir / "projects" / job.project_id / "latest" / "script" / "reviewed_script.json").exists()


def test_project_snapshot_reflects_latest_stage_and_failed_job_count(output_dir):
    runner = make_runner(output_dir)
    job = runner.create_job(JobCreate(topic="真假千金互换人生", duration_seconds=120, episode_count=1))

    snapshot = runner.project_store.project_snapshot(job.project_id, runner.job_store)

    assert snapshot.latest_job_id == job.job_id
    assert snapshot.latest_job_status == "script_review_pending"
    assert snapshot.script_status == "review_pending"
    assert snapshot.character_status == "not_started"
    assert snapshot.video_status == "not_started"
    assert snapshot.failed_job_count == 0


def test_pipeline_approves_script_and_stops_at_character_review(output_dir):
    runner = make_runner(output_dir)
    job = runner.create_job(JobCreate(topic="替嫁新娘逆袭", duration_seconds=60, episode_count=1))

    updated = runner.approve_script(job.job_id)

    assert updated.status == JobStatus.CHARACTER_REVIEW_PENDING
    assert (output_dir / "projects" / job.project_id / "runs" / job.job_id / "characters" / "female_lead" / "approved.png").exists()
    assert (output_dir / "projects" / job.project_id / "latest" / "script" / "reviewed_script.json").exists()
    assert not (output_dir / "projects" / job.project_id / "latest" / "characters" / "character_profiles.json").exists()


def test_reject_script_keeps_job_in_script_review_pending(output_dir):
    runner = make_runner(output_dir)
    job = runner.create_job(JobCreate(topic="真假千金互换人生", duration_seconds=120, episode_count=1))

    updated = runner.reject_script(job.job_id, reason="反转不够狠")

    assert updated.status == JobStatus.SCRIPT_REVIEW_PENDING
    assert "反转不够狠" in (updated.last_error or "")


def test_regenerate_script_rewrites_reviewed_script(output_dir):
    runner = make_runner(output_dir)
    job = runner.create_job(JobCreate(topic="真假千金互换人生", duration_seconds=120, episode_count=1))

    regenerated = runner.regenerate_script(job.job_id, notes="把女主写得更强势")

    assert regenerated.status == JobStatus.SCRIPT_REVIEW_PENDING
    script = runner.artifact_store.read_json(job.job_id, "script/reviewed_script.json")
    assert script["series_title"]


def test_pipeline_writes_script_quality_report_before_script_review(output_dir):
    artifact_store = ArtifactStore(output_dir)
    job_store = JobStore(output_dir / "jobs.sqlite3")
    project_store = ProjectStore(output_dir / "jobs.sqlite3")
    pipeline_logger = PipelineEventLogger(artifact_store)
    model_logger = ModelCallLogger(artifact_store)
    review_harness = ScriptReviewArtifactHarness(artifact_store)
    runner = PipelineRunner(
        artifact_store=artifact_store,
        job_store=job_store,
        project_store=project_store,
        script_provider=WarningHeavyScriptProvider(),
        image_provider=FakeImageProvider(output_dir, model_logger=model_logger),
        video_provider=FakeVideoProvider(output_dir, model_logger=model_logger),
        harness_manager=HarnessManager([review_harness]),
        pipeline_logger=pipeline_logger,
        model_logger=model_logger,
    )

    job = runner.create_job(JobCreate(topic="质量预警测试", duration_seconds=20, episode_count=1))

    report = runner.artifact_store.read_json(job.job_id, "harness/script_quality_report.json")
    assert job.status == JobStatus.SCRIPT_REVIEW_PENDING
    assert report["job_id"] == job.job_id
    assert report["shot_issues"]
    assert any(issue["title"] == "shot_duration_out_of_range" for issue in report["shot_issues"])
    assert report["summary"].endswith("不阻塞后续流程。")
    assert review_harness.before_review_report == report


def test_script_quality_warnings_do_not_block_script_review_pending(output_dir):
    artifact_store = ArtifactStore(output_dir)
    job_store = JobStore(output_dir / "jobs.sqlite3")
    project_store = ProjectStore(output_dir / "jobs.sqlite3")
    pipeline_logger = PipelineEventLogger(artifact_store)
    model_logger = ModelCallLogger(artifact_store)
    runner = PipelineRunner(
        artifact_store=artifact_store,
        job_store=job_store,
        project_store=project_store,
        script_provider=WarningHeavyScriptProvider(),
        image_provider=FakeImageProvider(output_dir, model_logger=model_logger),
        video_provider=FakeVideoProvider(output_dir, model_logger=model_logger),
        harness_manager=HarnessManager([]),
        pipeline_logger=pipeline_logger,
        model_logger=model_logger,
    )

    job = runner.create_job(JobCreate(topic="质量预警测试", duration_seconds=20, episode_count=1))

    report = runner.artifact_store.read_json(job.job_id, "harness/script_quality_report.json")
    assert job.status == JobStatus.SCRIPT_REVIEW_PENDING
    assert report["overall_score"] < 100
    assert report["episode_warnings"]["episode_01"]


def test_pipeline_approves_characters_and_completes(output_dir):
    runner = make_runner(output_dir)
    job = runner.create_job(JobCreate(topic="替嫁新娘逆袭", duration_seconds=60, episode_count=1))
    runner.approve_script(job.job_id)

    completed = runner.approve_characters(job.job_id)

    assert completed.status == JobStatus.COMPLETED
    assert (output_dir / "projects" / job.project_id / "runs" / job.job_id / "shots" / "episode_01.json").exists()
    assert (output_dir / "projects" / job.project_id / "runs" / job.job_id / "videos" / "episode_01" / "final.mp4").exists()


def test_reject_characters_keeps_job_in_character_review_pending(output_dir):
    runner = make_runner(output_dir)
    job = runner.create_job(JobCreate(topic="真假千金互换人生", duration_seconds=120, episode_count=1))
    runner.approve_script(job.job_id)

    updated = runner.reject_characters(job.job_id, reason="假千金不够跋扈")

    assert updated.status == JobStatus.CHARACTER_REVIEW_PENDING
    assert "假千金不够跋扈" in (updated.last_error or "")


def test_regenerate_character_updates_single_character_profile(output_dir):
    runner = make_runner(output_dir)
    job = runner.create_job(JobCreate(topic="真假千金互换人生", duration_seconds=120, episode_count=1))
    runner.approve_script(job.job_id)

    updated = runner.regenerate_character(job.job_id, "female_lead")

    assert updated.job_id == job.job_id
    characters = runner.artifact_store.read_json(job.job_id, "characters/character_profiles.json")
    female = next(character for character in characters if character["character_id"] == "female_lead")
    assert female["approved_reference_url"]


def test_video_composition_keeps_shot_order_even_when_completion_is_out_of_order(output_dir):
    class OutOfOrderVideoProvider:
        def generate_shot_video(self, job_id, episode_id, shot, output_dir=None):
            from pathlib import Path
            import time

            if shot.shot_order == 1:
                time.sleep(0.03)
            elif shot.shot_order == 2:
                time.sleep(0.01)
            path = Path(output_dir) / "videos" / episode_id / f"{shot.shot_id}.mp4"
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(shot.shot_id.encode("utf-8"))
            return VideoResult(episode_id=episode_id, shot_id=shot.shot_id, task_id=f"task_{shot.shot_id}", video_path=str(path))

    class OrderScriptProvider:
        def generate_script(self, job_id: str, request: JobCreate) -> ScriptBundle:
            profile = CharacterProfile(
                character_id="female_lead",
                name="林晚",
                role="女主",
                age_range="25-30",
                appearance="黑色长发",
                personality="坚韧",
                costume_style="白衬衫",
                voice_style="坚定",
                consistency_prompt="保持相同五官",
            )
            episode = Episode(
                episode_id="episode_01",
                title="顺序测试",
                duration_seconds=12,
                summary="并发顺序测试",
                hook="测试拼接顺序",
                shots=[
                    Shot(shot_id="S01", duration_seconds=6, scene_location="门口", characters=["female_lead"], visual_description="一", dialogue=[], camera="近景", emotion="平静"),
                    Shot(shot_id="S02", duration_seconds=6, scene_location="走廊", characters=["female_lead"], visual_description="二", dialogue=[], camera="近景", emotion="平静"),
                    Shot(shot_id="S03", duration_seconds=6, scene_location="房间", characters=["female_lead"], visual_description="三", dialogue=[], camera="近景", emotion="平静"),
                ],
            )
            return ScriptBundle(series_title=request.topic, series_bible="顺序测试", characters=[profile], episodes=[episode])

    artifact_store = ArtifactStore(output_dir)
    job_store = JobStore(output_dir / "jobs.sqlite3")
    project_store = ProjectStore(output_dir / "jobs.sqlite3")
    pipeline_logger = PipelineEventLogger(artifact_store)
    model_logger = ModelCallLogger(artifact_store)
    runner = PipelineRunner(
        artifact_store=artifact_store,
        job_store=job_store,
        project_store=project_store,
        script_provider=OrderScriptProvider(),
        image_provider=FakeImageProvider(output_dir, model_logger=model_logger),
        video_provider=OutOfOrderVideoProvider(),
        harness_manager=HarnessManager([]),
        pipeline_logger=pipeline_logger,
        model_logger=model_logger,
    )
    captured = {}

    class StubComposer:
        @staticmethod
        def compose(shot_paths, final_path):
            captured["ordered_shot_ids"] = [path.stem for path in shot_paths]
            final_path.parent.mkdir(parents=True, exist_ok=True)
            final_path.write_bytes(b"video")

    runner.composer = StubComposer()

    job = runner.create_job(JobCreate(topic="顺序测试", duration_seconds=12, episode_count=1))
    runner.approve_script(job.job_id)
    completed = runner.approve_characters(job.job_id)

    assert completed.status == JobStatus.COMPLETED
    assert captured["ordered_shot_ids"] == ["S01", "S02", "S03"]


def test_pipeline_continues_existing_project_without_regenerating_script_or_characters(output_dir):
    runner = make_runner(output_dir)
    initial = runner.create_job(JobCreate(topic="替嫁新娘逆袭", duration_seconds=60, episode_count=1))
    runner.approve_script(initial.job_id)
    runner.approve_characters(initial.job_id)

    script_provider = runner.script_provider
    image_provider = runner.image_provider

    continued = runner.create_job(
        JobCreate(
            topic="继续生成同项目视频",
            duration_seconds=60,
            episode_count=1,
            project_id=initial.project_id,
            notes="沿用已有剧本和人物，重新生成一版视频",
        )
    )

    assert continued.status == JobStatus.COMPLETED
    assert continued.project_id == initial.project_id
    assert script_provider.call_count == 1
    assert image_provider.call_count == 2
    assert (output_dir / "projects" / initial.project_id / "runs" / continued.job_id / "videos" / "episode_01" / "final.mp4").exists()


def test_pipeline_does_not_continue_project_without_approved_characters(output_dir):
    runner = make_runner(output_dir)
    initial = runner.create_job(JobCreate(topic="替嫁新娘逆袭", duration_seconds=60, episode_count=1))
    runner.approve_script(initial.job_id)

    script_provider = runner.script_provider
    image_provider = runner.image_provider

    continued = runner.create_job(
        JobCreate(
            topic="继续生成同项目视频",
            duration_seconds=60,
            episode_count=1,
            project_id=initial.project_id,
            notes="此时人物尚未批准，不应沿用 latest",
        )
    )

    assert continued.status == JobStatus.SCRIPT_REVIEW_PENDING
    assert continued.project_id == initial.project_id
    assert script_provider.call_count == 2
    assert image_provider.call_count == 2


def test_project_snapshot_remains_coherent_across_approval_stages(output_dir):
    runner = make_runner(output_dir)
    job = runner.create_job(JobCreate(topic="真假千金互换人生", duration_seconds=120, episode_count=1))

    pending_snapshot = runner.project_store.project_snapshot(job.project_id, runner.job_store)
    assert pending_snapshot.script_status == "review_pending"
    assert pending_snapshot.character_status == "not_started"
    assert pending_snapshot.video_status == "not_started"

    runner.approve_script(job.job_id)
    character_snapshot = runner.project_store.project_snapshot(job.project_id, runner.job_store)
    assert character_snapshot.script_status == "approved"
    assert character_snapshot.character_status == "review_pending"
    assert character_snapshot.video_status == "not_started"

    runner.approve_characters(job.job_id)
    completed_snapshot = runner.project_store.project_snapshot(job.project_id, runner.job_store)
    assert completed_snapshot.script_status == "approved"
    assert completed_snapshot.character_status == "approved"
    assert completed_snapshot.video_status == "completed"


def test_pipeline_logs_model_calls_with_task_and_video_details(output_dir):
    runner = make_runner(output_dir)
    job = runner.create_job(JobCreate(topic="替嫁新娘逆袭", duration_seconds=60, episode_count=1))
    runner.approve_script(job.job_id)
    runner.approve_characters(job.job_id)

    log_path = output_dir / "projects" / job.project_id / "runs" / job.job_id / "logs" / "model_calls.jsonl"
    entries = [json.loads(line) for line in log_path.read_text(encoding="utf-8").splitlines()]

    operations = {entry["operation"] for entry in entries}
    assert "generate_script" in operations
    assert "generate_character_image" in operations
    assert "seedance_create_task" in operations
    assert "seedance_poll_status" in operations
    assert "seedance_download_video" in operations
    assert any(entry.get("task_id", "").startswith("fake_seedance_") for entry in entries)
    assert any(str(entry.get("video_url", "")).endswith(".mp4") for entry in entries)


def test_pipeline_splits_long_shots_before_video_generation(output_dir):
    artifact_store = ArtifactStore(output_dir)
    job_store = JobStore(output_dir / "jobs.sqlite3")
    project_store = ProjectStore(output_dir / "jobs.sqlite3")
    pipeline_logger = PipelineEventLogger(artifact_store)
    model_logger = ModelCallLogger(artifact_store)
    video_provider = RecordingVideoProvider(output_dir)
    runner = PipelineRunner(
        artifact_store=artifact_store,
        job_store=job_store,
        project_store=project_store,
        script_provider=LongShotScriptProvider(),
        image_provider=FakeImageProvider(output_dir, model_logger=model_logger),
        video_provider=video_provider,
        harness_manager=HarnessManager([]),
        pipeline_logger=pipeline_logger,
        model_logger=model_logger,
    )
    runner.composer = type(
        "StubComposer",
        (),
        {
            "compose": staticmethod(
                lambda shot_paths, final_path: final_path.parent.mkdir(parents=True, exist_ok=True)
                or final_path.write_bytes(b"video")
            )
        },
    )()

    job = runner.create_job(JobCreate(topic="长镜头测试", duration_seconds=21, episode_count=1))
    runner.approve_script(job.job_id)
    completed = runner.approve_characters(job.job_id)

    assert completed.status == JobStatus.COMPLETED
    assert video_provider.durations == [10, 11]


def test_pipeline_merges_short_shots_before_video_generation(output_dir):
    artifact_store = ArtifactStore(output_dir)
    job_store = JobStore(output_dir / "jobs.sqlite3")
    project_store = ProjectStore(output_dir / "jobs.sqlite3")
    pipeline_logger = PipelineEventLogger(artifact_store)
    model_logger = ModelCallLogger(artifact_store)
    video_provider = RecordingVideoProvider(output_dir)
    runner = PipelineRunner(
        artifact_store=artifact_store,
        job_store=job_store,
        project_store=project_store,
        script_provider=ShortShotScriptProvider(),
        image_provider=FakeImageProvider(output_dir, model_logger=model_logger),
        video_provider=video_provider,
        harness_manager=HarnessManager([]),
        pipeline_logger=pipeline_logger,
        model_logger=model_logger,
    )
    runner.composer = type(
        "StubComposer",
        (),
        {
            "compose": staticmethod(
                lambda shot_paths, final_path: final_path.parent.mkdir(parents=True, exist_ok=True)
                or final_path.write_bytes(b"video")
            )
        },
    )()

    job = runner.create_job(JobCreate(topic="短镜头测试", duration_seconds=12, episode_count=1))
    runner.approve_script(job.job_id)
    completed = runner.approve_characters(job.job_id)

    assert completed.status == JobStatus.COMPLETED
    assert video_provider.durations == [9]


def test_failed_continue_project_marks_job_failed_and_preserves_latest_job(output_dir):
    success_runner = make_runner(output_dir)
    initial = success_runner.create_job(JobCreate(topic="替嫁新娘逆袭", duration_seconds=60, episode_count=1))
    success_runner.approve_script(initial.job_id)
    success_runner.approve_characters(initial.job_id)

    artifact_store = ArtifactStore(output_dir)
    job_store = JobStore(output_dir / "jobs.sqlite3")
    project_store = ProjectStore(output_dir / "jobs.sqlite3")
    for job in job_store.list_jobs():
        artifact_store.register_job_dir(job.job_id, job.artifact_dir)
    pipeline_logger = PipelineEventLogger(artifact_store)
    model_logger = ModelCallLogger(artifact_store)
    runner = PipelineRunner(
        artifact_store=artifact_store,
        job_store=job_store,
        project_store=project_store,
        script_provider=FakeScriptProvider(model_logger=model_logger),
        image_provider=FakeImageProvider(output_dir, model_logger=model_logger),
        video_provider=FailingVideoProvider(),
        harness_manager=HarnessManager([]),
        pipeline_logger=pipeline_logger,
        model_logger=model_logger,
    )

    with pytest.raises(RuntimeError, match="Seedance 创建任务失败"):
        runner.create_job(
            JobCreate(
                topic="继续生成同项目视频",
                duration_seconds=60,
                episode_count=1,
                project_id=initial.project_id,
            )
        )

    failed_job = job_store.list_jobs()[0]
    project = project_store.get_project(initial.project_id)

    assert failed_job.status == JobStatus.FAILED
    assert "Seedance 创建任务失败" in (failed_job.last_error or "")
    assert project.latest_job_id == initial.job_id


def test_pipeline_retries_script_phase_once_before_failing(output_dir):
    artifact_store = ArtifactStore(output_dir)
    job_store = JobStore(output_dir / "jobs.sqlite3")
    project_store = ProjectStore(output_dir / "jobs.sqlite3")
    pipeline_logger = PipelineEventLogger(artifact_store)
    model_logger = ModelCallLogger(artifact_store)
    script_provider = FlakyScriptProvider()
    runner = PipelineRunner(
        artifact_store=artifact_store,
        job_store=job_store,
        project_store=project_store,
        script_provider=script_provider,
        image_provider=FakeImageProvider(output_dir, model_logger=model_logger),
        video_provider=FakeVideoProvider(output_dir, model_logger=model_logger),
        harness_manager=HarnessManager([]),
        pipeline_logger=pipeline_logger,
        model_logger=model_logger,
    )

    job = runner.create_job(JobCreate(topic="重试一次", duration_seconds=60, episode_count=1))

    assert job.status == JobStatus.SCRIPT_REVIEW_PENDING
    assert script_provider.calls == 2
    log_path = output_dir / "projects" / job.project_id / "runs" / job.job_id / "logs" / "pipeline_events.jsonl"
    events = [json.loads(line) for line in log_path.read_text(encoding="utf-8").splitlines()]
    assert any(event["event"] == "script_generation_retry" for event in events)
