from fastapi.testclient import TestClient

from shortdrama_pipeline.api import create_app


def test_create_job_and_get_status(output_dir):
    app = create_app(output_dir=output_dir)
    client = TestClient(app)

    response = client.post(
        "/jobs",
        json={
            "topic": "替嫁新娘逆袭",
            "duration_seconds": 60,
            "episode_count": 1,
            "ratio": "9:16",
            "style": "都市情感，强反转",
            "notes": "结尾要有钩子",
        },
    )

    assert response.status_code == 200
    job_id = response.json()["job_id"]

    status = client.get(f"/jobs/{job_id}")
    assert status.status_code == 200
    assert status.json()["status"] == "script_review_pending"


def test_approve_script_endpoint(output_dir):
    app = create_app(output_dir=output_dir)
    client = TestClient(app)
    job_id = client.post(
        "/jobs",
        json={"topic": "替嫁新娘逆袭", "duration_seconds": 60, "episode_count": 1},
    ).json()["job_id"]

    response = client.post(f"/jobs/{job_id}/script/approve")

    assert response.status_code == 200
    assert response.json()["status"] == "character_review_pending"


def test_continue_endpoint_advances_from_review_states(output_dir):
    app = create_app(output_dir=output_dir)
    client = TestClient(app)
    job_id = client.post(
        "/jobs",
        json={"topic": "替嫁新娘逆袭", "duration_seconds": 60, "episode_count": 1},
    ).json()["job_id"]

    first = client.post(f"/jobs/{job_id}/continue")
    second = client.post(f"/jobs/{job_id}/continue")

    assert first.status_code == 200
    assert first.json()["status"] == "character_review_pending"
    assert second.status_code == 200
    assert second.json()["status"] == "completed"


def test_cancel_endpoint_marks_job_cancelled(output_dir):
    app = create_app(output_dir=output_dir)
    client = TestClient(app)
    job_id = client.post(
        "/jobs",
        json={"topic": "替嫁新娘逆袭", "duration_seconds": 60, "episode_count": 1},
    ).json()["job_id"]

    response = client.post(f"/jobs/{job_id}/cancel")

    assert response.status_code == 200
    assert response.json()["status"] == "cancelled"
