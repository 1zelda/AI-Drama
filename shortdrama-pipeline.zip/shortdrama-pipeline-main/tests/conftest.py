from pathlib import Path

import pytest


@pytest.fixture(autouse=True)
def force_fake_provider_for_tests(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("SHORTDRAMA_PROVIDER_MODE", "fake")


@pytest.fixture
def output_dir(tmp_path: Path) -> Path:
    return tmp_path / "outputs"
