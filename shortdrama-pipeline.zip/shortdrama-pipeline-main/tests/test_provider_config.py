import pytest
import json
import httpx

from shortdrama_pipeline.logging import ModelCallLogger
from shortdrama_pipeline.config import Settings, load_settings
from shortdrama_pipeline.models import JobCreate, Shot
from shortdrama_pipeline.storage import ArtifactStore
from shortdrama_pipeline.providers import ArkProviderFactory, ArkSeedanceProvider, normalize_script_data
from shortdrama_pipeline.providers import ArkScriptProvider


def test_provider_factory_uses_fake_when_no_api_key(output_dir):
    settings = Settings(output_dir=output_dir, db_path=output_dir / "jobs.sqlite3", ark_api_key=None)
    factory = ArkProviderFactory(settings)

    providers = factory.create(fake_when_missing_key=True)

    assert providers.script.__class__.__name__ == "FakeScriptProvider"
    assert providers.image.__class__.__name__ == "FakeImageProvider"
    assert providers.video.__class__.__name__ == "FakeVideoProvider"


def test_seedance_concurrency_is_capped_at_five():
    settings = Settings(seedance_concurrency=9)
    assert settings.seedance_concurrency == 5


def test_seedance_concurrency_keeps_default_two():
    settings = Settings()
    assert settings.seedance_concurrency == 2


def test_seedance_poll_settings_keep_defaults():
    settings = Settings()

    assert settings.seedance_poll_interval_seconds == 15
    assert settings.seedance_max_wait_seconds == 1800


def test_seedance_poll_settings_are_clamped_to_minimum_one():
    settings = Settings(seedance_poll_interval_seconds=0, seedance_max_wait_seconds=-5)

    assert settings.seedance_poll_interval_seconds == 1
    assert settings.seedance_max_wait_seconds == 1


def test_load_settings_reads_seedance_concurrency_from_env_file(tmp_path, monkeypatch):
    env_path = tmp_path / ".env"
    env_path.write_text("SHORTDRAMA_SEEDANCE_CONCURRENCY=4\n", encoding="utf-8")
    monkeypatch.delenv("SHORTDRAMA_SEEDANCE_CONCURRENCY", raising=False)

    settings = load_settings(env_file=env_path)

    assert settings.seedance_concurrency == 4


def test_load_settings_reads_seedance_polling_values_from_env_file(tmp_path, monkeypatch):
    env_path = tmp_path / ".env"
    env_path.write_text(
        "SHORTDRAMA_SEEDANCE_POLL_INTERVAL_SECONDS=7\n"
        "SHORTDRAMA_SEEDANCE_MAX_WAIT_SECONDS=210\n",
        encoding="utf-8",
    )
    monkeypatch.delenv("SHORTDRAMA_SEEDANCE_POLL_INTERVAL_SECONDS", raising=False)
    monkeypatch.delenv("SHORTDRAMA_SEEDANCE_MAX_WAIT_SECONDS", raising=False)

    settings = load_settings(env_file=env_path)

    assert settings.seedance_poll_interval_seconds == 7
    assert settings.seedance_max_wait_seconds == 210


def test_provider_factory_fake_mode_overrides_api_key(output_dir):
    settings = Settings(
        output_dir=output_dir,
        db_path=output_dir / "jobs.sqlite3",
        ark_api_key="dummy",
        provider_mode="fake",
    )
    providers = ArkProviderFactory(settings).create()

    assert providers.script.__class__.__name__ == "FakeScriptProvider"


def test_provider_factory_ark_mode_requires_api_key(output_dir):
    settings = Settings(
        output_dir=output_dir,
        db_path=output_dir / "jobs.sqlite3",
        ark_api_key=None,
        provider_mode="ark",
    )

    with pytest.raises(ValueError, match="缺少 ARK_API_KEY"):
        ArkProviderFactory(settings).create()


def test_real_seedance_rejects_local_reference_image(output_dir):
    settings = Settings(output_dir=output_dir, db_path=output_dir / "jobs.sqlite3", ark_api_key="dummy")
    provider = ArkSeedanceProvider(settings)
    shot = Shot(
        shot_id="shot_001",
        duration_seconds=8,
        scene_location="医院走廊",
        characters=["female_lead"],
        visual_description="女主站在门口。",
        dialogue=[],
        camera="中景",
        emotion="紧张",
        seedance_prompt="中文镜头 Prompt",
        reference_images=["/tmp/local-approved.png"],
    )

    with pytest.raises(ValueError, match="公网可访问"):
        provider.generate_shot_video("job_abc", "episode_01", shot)


def test_seedance_status_urls_try_operator_then_ark(output_dir):
    settings = Settings(output_dir=output_dir, db_path=output_dir / "jobs.sqlite3", ark_api_key="dummy")
    provider = ArkSeedanceProvider(settings)

    urls = provider._task_status_urls("cgt-123")

    assert urls[0].startswith("https://operator.las.cn-beijing.volces.com/api/v1/")
    assert urls[1].startswith("https://ark.cn-beijing.volces.com/api/v3/")


def test_seedance_wait_uses_configured_poll_interval_and_timeout(output_dir, monkeypatch):
    settings = Settings(
        output_dir=output_dir,
        db_path=output_dir / "jobs.sqlite3",
        ark_api_key="dummy",
        seedance_poll_interval_seconds=3,
        seedance_max_wait_seconds=8,
    )
    provider = ArkSeedanceProvider(settings)
    sleep_calls = []
    current_time = 0

    def fake_fetch_task_status(task_id):
        return {"status": "running"}

    def fake_sleep(seconds):
        nonlocal current_time
        sleep_calls.append(seconds)
        current_time += seconds

    def fake_monotonic():
        return current_time

    monkeypatch.setattr(provider, "_fetch_task_status", fake_fetch_task_status)
    monkeypatch.setattr("shortdrama_pipeline.providers.time.sleep", fake_sleep)
    monkeypatch.setattr("shortdrama_pipeline.providers.time.monotonic", fake_monotonic)

    with pytest.raises(TimeoutError, match="Seedance 任务超时"):
        provider._wait_for_video_url("job_abc", "task_123")

    assert sleep_calls == [3, 3, 2]


def test_normalize_script_data_coerces_model_variants():
    data = {
        "series_title": "保洁阿姨真实身份是首富千金",
        "series_bible": "中文短剧设定",
        "characters": [
            {
                "character_id": 1,
                "name": "林晚",
                "role": "女主",
                "age_range": "25-30",
                "appearance": "黑色长发",
                "personality": "隐忍",
                "costume_style": "保洁制服",
                "voice_style": "冷静",
                "consistency_prompt": "保持同一张脸",
            }
        ],
        "episodes": [
            {
                "episode_id": 1,
                "title": "羞辱",
                "duration_seconds": 30,
                "summary": "女主被羞辱。",
                "hook": "身份反转。",
                "shots": [
                    {
                        "shot_id": 1,
                        "duration_seconds": 8,
                        "scene_location": "商场大厅",
                        "characters": [1],
                        "visual_description": "女主低头清理地面。",
                        "dialogue": "女主：我给你最后一次机会。",
                        "camera": "中景推进",
                        "emotion": "克制",
                    }
                ],
            }
        ],
    }

    script = normalize_script_data(data)

    assert script.characters[0].character_id == "1"
    assert script.episodes[0].episode_id == "1"
    assert script.episodes[0].shots[0].shot_id == "1"
    assert script.episodes[0].shots[0].characters == ["1"]
    assert script.episodes[0].shots[0].dialogue == ["女主：我给你最后一次机会。"]


def test_seedance_logs_error_body_when_create_task_fails(output_dir):
    settings = Settings(output_dir=output_dir, db_path=output_dir / "jobs.sqlite3", ark_api_key="dummy")
    artifact_store = ArtifactStore(output_dir)
    artifact_store.create_job_dir("job_abc")
    logger = ModelCallLogger(artifact_store)
    provider = ArkSeedanceProvider(settings, model_logger=logger)

    class FakeClient:
        def post(self, url, headers=None, json=None):
            return httpx.Response(
                400,
                request=httpx.Request("POST", url),
                json={"error": {"code": "InvalidParameter", "message": "duration invalid"}},
            )

    provider.client = FakeClient()
    shot = Shot(
        shot_id="shot_001",
        duration_seconds=35,
        scene_location="医院走廊",
        characters=["female_lead"],
        visual_description="女主站在门口。",
        dialogue=[],
        camera="中景",
        emotion="紧张",
        seedance_prompt="中文镜头 Prompt",
        reference_images=["https://example.com/a.png"],
    )

    with pytest.raises(httpx.HTTPStatusError):
        provider.generate_shot_video("job_abc", "episode_01", shot, output_dir=str(output_dir / "job_abc"))

    log_path = output_dir / "job_abc" / "logs" / "model_calls.jsonl"
    entries = [json.loads(line) for line in log_path.read_text(encoding="utf-8").splitlines()]
    failure = entries[-1]
    assert failure["operation"] == "seedance_create_task_failed"
    assert failure["response_status"] == 400
    assert "duration invalid" in failure["response_body"]


def test_ark_script_provider_logs_raw_output_and_repairs_invalid_json(output_dir):
    settings = Settings(output_dir=output_dir, db_path=output_dir / "jobs.sqlite3", ark_api_key="dummy")
    artifact_store = ArtifactStore(output_dir)
    artifact_store.create_job_dir("job_abc")
    logger = ModelCallLogger(artifact_store)
    provider = ArkScriptProvider(settings, model_logger=logger)

    class FakeResponse:
        def __init__(self, output_text):
            self.output_text = output_text

    class FakeResponses:
        def __init__(self):
            self.calls = 0

        def create(self, model=None, input=None):
            self.calls += 1
            if self.calls == 1:
                return FakeResponse('{"series_title":"坏 JSON","series_bible":"x","characters":[],"episodes":[{"episode_id":"1"}]}尾巴')
            return FakeResponse(
                json.dumps(
                    {
                        "series_title": "修复成功",
                        "series_bible": "中文短剧设定",
                        "characters": [],
                        "episodes": [],
                    },
                    ensure_ascii=False,
                )
            )

    class FakeClient:
        def __init__(self):
            self.responses = FakeResponses()

    provider.client = FakeClient()

    script = provider.generate_script("job_abc", JobCreate(topic="修复 JSON", duration_seconds=60, episode_count=1))

    assert script.series_title == "修复成功"
    log_path = output_dir / "job_abc" / "logs" / "model_calls.jsonl"
    entries = [json.loads(line) for line in log_path.read_text(encoding="utf-8").splitlines()]
    assert any(entry["operation"] == "generate_script_raw_response" and entry["stage"] == "initial" for entry in entries)
    assert any(entry["operation"] == "generate_script_parse_failed" for entry in entries)
    assert any(entry["operation"] == "generate_script_raw_response" and entry["stage"] == "repair" for entry in entries)
    assert any(entry["operation"] == "generate_script" and entry["repair_used"] is True for entry in entries)
