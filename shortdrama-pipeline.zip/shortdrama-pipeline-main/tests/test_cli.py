from typer.testing import CliRunner

from shortdrama_pipeline.harness import HarnessManager
from shortdrama_pipeline.logging import ModelCallLogger, PipelineEventLogger
from shortdrama_pipeline.cli import app
from shortdrama_pipeline.pipeline import PipelineRunner
from shortdrama_pipeline.models import JobCreate, JobStatus
from shortdrama_pipeline.providers import FakeImageProvider, FakeScriptProvider, FakeVideoProvider
from shortdrama_pipeline.storage import ArtifactStore, JobStore, ProjectStore


def make_runner(output_dir):
    artifact_store = ArtifactStore(output_dir)
    job_store = JobStore(output_dir / "jobs.sqlite3")
    project_store = ProjectStore(output_dir / "jobs.sqlite3")
    pipeline_logger = PipelineEventLogger(artifact_store)
    model_logger = ModelCallLogger(artifact_store)
    return PipelineRunner(
        artifact_store=artifact_store,
        job_store=job_store,
        project_store=project_store,
        script_provider=FakeScriptProvider(model_logger=model_logger),
        image_provider=FakeImageProvider(output_dir, model_logger=model_logger),
        video_provider=FakeVideoProvider(output_dir, model_logger=model_logger),
        harness_manager=HarnessManager([]),
        pipeline_logger=pipeline_logger,
        model_logger=model_logger,
    )


def test_cli_shows_help():
    runner = CliRunner()
    result = runner.invoke(app, ["--help"])

    assert result.exit_code == 0
    assert "中文短剧生产流水线" in result.output


def test_cli_review_requires_job_id():
    runner = CliRunner()
    result = runner.invoke(app, ["review"])

    assert result.exit_code != 0


def test_cli_has_continue_command():
    runner = CliRunner()
    result = runner.invoke(app, ["continue", "--help"])

    assert result.exit_code == 0
    assert "继续当前审核后的流水线" in result.output


def test_cli_has_smoke_ark_command():
    runner = CliRunner()
    result = runner.invoke(app, ["smoke-ark", "--help"])

    assert result.exit_code == 0
    assert "测试 Ark 线上文本模型连通性" in result.output


def test_cli_create_supports_interactive_prompts(output_dir, monkeypatch):
    runner = CliRunner()
    pipeline_runner = make_runner(output_dir)
    monkeypatch.setattr("shortdrama_pipeline.cli.build_runner", lambda *args, **kwargs: pipeline_runner)

    result = runner.invoke(
        app,
        ["create"],
        input="替嫁新娘逆袭\n60\n1\n\n\n",
    )

    assert result.exit_code == 0
    assert "任务已创建" in result.output
    assert "script_review_pending" in result.output
    assert len(pipeline_runner.job_store.list_jobs()) == 1


def test_cli_lists_projects(output_dir, monkeypatch):
    runner = CliRunner()
    pipeline_runner = make_runner(output_dir)
    job = pipeline_runner.create_job(
        __import__("shortdrama_pipeline.models", fromlist=["JobCreate"]).JobCreate(
            topic="替嫁新娘逆袭", duration_seconds=60, episode_count=1
        )
    )
    monkeypatch.setattr("shortdrama_pipeline.cli.build_runner", lambda *args, **kwargs: pipeline_runner)

    result = runner.invoke(app, ["projects"])

    assert result.exit_code == 0
    assert job.project_id in result.output
    assert "替嫁新娘逆袭" in result.output


def test_cli_project_latest_shows_paths(output_dir, monkeypatch):
    runner = CliRunner()
    pipeline_runner = make_runner(output_dir)
    job = pipeline_runner.create_job(
        __import__("shortdrama_pipeline.models", fromlist=["JobCreate"]).JobCreate(
            topic="替嫁新娘逆袭", duration_seconds=60, episode_count=1
        )
    )
    pipeline_runner.approve_script(job.job_id)
    pipeline_runner.approve_characters(job.job_id)
    monkeypatch.setattr("shortdrama_pipeline.cli.build_runner", lambda *args, **kwargs: pipeline_runner)

    result = runner.invoke(app, ["project-latest", job.project_id])

    assert result.exit_code == 0
    assert "剧名：替嫁新娘逆袭" in result.output
    assert "人物：林晚、沈砚" in result.output
    assert "reviewed_script.json" in result.output
    assert "character_profiles.json" in result.output
    assert "final.mp4" in result.output


def test_cli_project_dashboard_shows_snapshot_and_next_actions(output_dir, monkeypatch):
    runner = CliRunner()
    pipeline_runner = make_runner(output_dir)
    job = pipeline_runner.create_job(JobCreate(topic="真假千金互换人生", duration_seconds=120, episode_count=1))
    monkeypatch.setattr("shortdrama_pipeline.cli.build_runner", lambda *args, **kwargs: pipeline_runner)

    result = runner.invoke(app, ["project-dashboard", job.project_id])

    assert result.exit_code == 0
    assert "当前项目状态" in result.output
    assert "阶段：" in result.output
    assert "剧本待审核" in result.output
    assert "剧本质检" in result.output
    assert "下一步建议" in result.output


def test_cli_continue_project_creates_new_run(output_dir, monkeypatch):
    runner = CliRunner()
    pipeline_runner = make_runner(output_dir)
    initial = pipeline_runner.create_job(
        __import__("shortdrama_pipeline.models", fromlist=["JobCreate"]).JobCreate(
            topic="替嫁新娘逆袭", duration_seconds=60, episode_count=1
        )
    )
    pipeline_runner.approve_script(initial.job_id)
    pipeline_runner.approve_characters(initial.job_id)
    script_provider = pipeline_runner.script_provider
    image_provider = pipeline_runner.image_provider
    monkeypatch.setattr("shortdrama_pipeline.cli.build_runner", lambda *args, **kwargs: pipeline_runner)

    result = runner.invoke(
        app,
        ["continue-project", initial.project_id, "--notes", "沿用项目设定继续生成"],
    )

    assert result.exit_code == 0
    assert "任务已创建" in result.output
    assert "completed" in result.output
    assert len(pipeline_runner.job_store.list_jobs()) == 2
    assert script_provider.call_count == 1
    assert image_provider.call_count == 2


def test_cli_continue_project_requires_approved_reusable_assets(output_dir, monkeypatch):
    runner = CliRunner()
    pipeline_runner = make_runner(output_dir)
    initial = pipeline_runner.create_job(JobCreate(topic="替嫁新娘逆袭", duration_seconds=60, episode_count=1))
    monkeypatch.setattr("shortdrama_pipeline.cli.build_runner", lambda *args, **kwargs: pipeline_runner)

    result = runner.invoke(app, ["continue-project", initial.project_id, "--notes", "沿用项目设定继续生成"])

    assert result.exit_code != 0
    assert "尚未沉淀已批准的剧本和人物" in result.output


def test_cli_approve_script_prints_character_generation_logs(output_dir, monkeypatch):
    runner = CliRunner()
    pipeline_runner = make_runner(output_dir)
    job = pipeline_runner.create_job(
        __import__("shortdrama_pipeline.models", fromlist=["JobCreate"]).JobCreate(
            topic="替嫁新娘逆袭", duration_seconds=60, episode_count=1
        )
    )
    monkeypatch.setattr("shortdrama_pipeline.cli.build_runner", lambda *args, **kwargs: pipeline_runner)

    result = runner.invoke(app, ["approve-script", job.job_id])

    assert result.exit_code == 0
    assert "开始生成人物：林晚" in result.output
    assert "人物已生成：林晚" in result.output
    assert "approved.png" in result.output


def test_cli_reject_and_regenerate_character_commands(output_dir, monkeypatch):
    runner = CliRunner()
    pipeline_runner = make_runner(output_dir)
    job = pipeline_runner.create_job(JobCreate(topic="真假千金互换人生", duration_seconds=120, episode_count=1))
    pipeline_runner.approve_script(job.job_id)
    monkeypatch.setattr("shortdrama_pipeline.cli.build_runner", lambda *args, **kwargs: pipeline_runner)

    reject_result = runner.invoke(app, ["reject-characters", job.job_id, "--reason", "假千金不够跋扈"])
    regen_result = runner.invoke(app, ["regenerate-character", job.job_id, "female_lead"])

    assert reject_result.exit_code == 0
    assert regen_result.exit_code == 0


def test_cli_shell_can_list_projects_and_show_project_latest(output_dir, monkeypatch):
    runner = CliRunner()
    pipeline_runner = make_runner(output_dir)
    job = pipeline_runner.create_job(
        __import__("shortdrama_pipeline.models", fromlist=["JobCreate"]).JobCreate(
            topic="替嫁新娘逆袭", duration_seconds=60, episode_count=1
        )
    )
    pipeline_runner.approve_script(job.job_id)
    pipeline_runner.approve_characters(job.job_id)
    monkeypatch.setattr("shortdrama_pipeline.cli.build_runner", lambda *args, **kwargs: pipeline_runner)

    result = runner.invoke(
        app,
        ["shell"],
        input="2\n3\n1\n0\n",
    )

    assert result.exit_code == 0
    assert "交互菜单" in result.output
    assert job.project_id in result.output
    assert "剧名：替嫁新娘逆袭" in result.output
    assert "人物：林晚、沈砚" in result.output


def test_cli_shell_can_pick_project_by_number(output_dir, monkeypatch):
    runner = CliRunner()
    pipeline_runner = make_runner(output_dir)
    first = pipeline_runner.create_job(JobCreate(topic="真假千金互换人生", duration_seconds=120, episode_count=1))
    second = pipeline_runner.create_job(JobCreate(topic="替嫁新娘逆袭", duration_seconds=90, episode_count=1))
    pipeline_runner.approve_script(second.job_id)
    pipeline_runner.approve_characters(second.job_id)
    monkeypatch.setattr("shortdrama_pipeline.cli.build_runner", lambda *args, **kwargs: pipeline_runner)

    result = runner.invoke(app, ["shell"], input="3\n2\n0\n")

    assert result.exit_code == 0
    assert second.project_id in result.output
    assert first.project_id in result.output


def test_cli_shell_can_continue_project(output_dir, monkeypatch):
    runner = CliRunner()
    pipeline_runner = make_runner(output_dir)
    initial = pipeline_runner.create_job(
        __import__("shortdrama_pipeline.models", fromlist=["JobCreate"]).JobCreate(
            topic="替嫁新娘逆袭", duration_seconds=60, episode_count=1
        )
    )
    pipeline_runner.approve_script(initial.job_id)
    pipeline_runner.approve_characters(initial.job_id)
    monkeypatch.setattr("shortdrama_pipeline.cli.build_runner", lambda *args, **kwargs: pipeline_runner)

    result = runner.invoke(
        app,
        ["shell"],
        input="4\n1\n沿用项目设定继续生成\n0\n",
    )

    assert result.exit_code == 0
    assert "任务已创建" in result.output
    assert "completed" in result.output
    assert len(pipeline_runner.job_store.list_jobs()) == 2


def test_cli_shell_can_create_list_status_review_and_open_job(output_dir, monkeypatch):
    runner = CliRunner()
    pipeline_runner = make_runner(output_dir)
    monkeypatch.setattr("shortdrama_pipeline.cli.build_runner", lambda *args, **kwargs: pipeline_runner)

    result = runner.invoke(
        app,
        ["shell"],
        input="1\n失忆女总裁回村认亲\n90\n2\n\n\n5\n6\n1\n7\n1\n10\n1\n0\n",
    )

    assert result.exit_code == 0
    assert "任务已创建" in result.output
    created_job = pipeline_runner.job_store.list_jobs()[0]
    assert created_job.job_id in result.output
    assert "script_review_pending" in result.output
    assert "查看剧本摘要" in result.output
    assert str(created_job.artifact_dir.resolve()) in result.output


def test_cli_review_shows_script_quality_summary(output_dir, monkeypatch):
    runner = CliRunner()
    pipeline_runner = make_runner(output_dir)
    job = pipeline_runner.create_job(JobCreate(topic="失忆女总裁回村认亲", duration_seconds=90, episode_count=2))
    monkeypatch.setattr("shortdrama_pipeline.cli.build_runner", lambda *args, **kwargs: pipeline_runner)

    result = runner.invoke(app, ["review", job.job_id])

    assert result.exit_code == 0
    assert "剧本质检" in result.output
    assert "summary" not in result.output
    assert "shot_duration_out_of_range" in result.output or "预警" in result.output


def test_cli_shell_can_approve_script_and_characters(output_dir, monkeypatch):
    runner = CliRunner()
    pipeline_runner = make_runner(output_dir)
    job = pipeline_runner.create_job(
        __import__("shortdrama_pipeline.models", fromlist=["JobCreate"]).JobCreate(
            topic="替嫁新娘逆袭", duration_seconds=60, episode_count=1
        )
    )
    monkeypatch.setattr("shortdrama_pipeline.cli.build_runner", lambda *args, **kwargs: pipeline_runner)

    result = runner.invoke(
        app,
        ["shell"],
        input="8\n1\n9\n1\n0\n",
    )

    assert result.exit_code == 0
    assert "character_review_pending" in result.output
    assert "completed" in result.output


def test_cli_shell_handles_continue_project_failure_without_traceback(output_dir, monkeypatch):
    runner = CliRunner()

    class FailingVideoProvider:
        def generate_shot_video(self, job_id, episode_id, shot, output_dir=None):
            raise RuntimeError("Seedance 创建任务失败：duration 超限")

    artifact_store = ArtifactStore(output_dir)
    job_store = JobStore(output_dir / "jobs.sqlite3")
    project_store = ProjectStore(output_dir / "jobs.sqlite3")
    pipeline_logger = PipelineEventLogger(artifact_store)
    model_logger = ModelCallLogger(artifact_store)
    pipeline_runner = PipelineRunner(
        artifact_store=artifact_store,
        job_store=job_store,
        project_store=project_store,
        script_provider=FakeScriptProvider(model_logger=model_logger),
        image_provider=FakeImageProvider(output_dir, model_logger=model_logger),
        video_provider=FailingVideoProvider(),
        harness_manager=HarnessManager([]),
        pipeline_logger=pipeline_logger,
        model_logger=model_logger,
    )
    job = pipeline_runner.create_job(
        __import__("shortdrama_pipeline.models", fromlist=["JobCreate"]).JobCreate(
            topic="替嫁新娘逆袭", duration_seconds=60, episode_count=1
        )
    )
    pipeline_runner.approve_script(job.job_id)
    monkeypatch.setattr("shortdrama_pipeline.cli.build_runner", lambda *args, **kwargs: pipeline_runner)

    result = runner.invoke(
        app,
        ["shell"],
        input="9\n1\n0\n",
    )

    assert result.exit_code == 0
    assert "执行失败" in result.output
    assert "Traceback" not in result.output


def test_cli_failed_summary_shows_seedance_payload_and_response(output_dir, monkeypatch):
    runner = CliRunner()
    pipeline_runner = make_runner(output_dir)
    initial = pipeline_runner.create_job(JobCreate(topic="真假千金互换人生", duration_seconds=120, episode_count=1))
    pipeline_runner.approve_script(initial.job_id)
    pipeline_runner.approve_characters(initial.job_id)

    artifact_store = ArtifactStore(output_dir)
    job_store = JobStore(output_dir / "jobs.sqlite3")
    project_store = ProjectStore(output_dir / "jobs.sqlite3")
    for job in job_store.list_jobs():
        artifact_store.register_job_dir(job.job_id, job.artifact_dir)
    failure_runner = PipelineRunner(
        artifact_store=artifact_store,
        job_store=job_store,
        project_store=project_store,
        script_provider=FakeScriptProvider(),
        image_provider=FakeImageProvider(output_dir),
        video_provider=type(
            "FailingVideoProvider",
            (),
            {"generate_shot_video": staticmethod(lambda *args, **kwargs: (_ for _ in ()).throw(RuntimeError("Seedance 创建任务失败：duration 超限")))},
        )(),
        harness_manager=HarnessManager([]),
        pipeline_logger=PipelineEventLogger(artifact_store),
        model_logger=ModelCallLogger(artifact_store),
    )
    with __import__("pytest").raises(RuntimeError):
        failure_runner.create_job(JobCreate(topic="继续生成同项目视频", duration_seconds=120, episode_count=1, project_id=initial.project_id))
    failed_job = job_store.list_jobs()[0]
    model_log = failed_job.artifact_dir / "logs" / "model_calls.jsonl"
    model_log.parent.mkdir(parents=True, exist_ok=True)
    model_log.write_text(
        '{"operation":"seedance_create_task_failed","response_status":400,"response_body":"duration invalid","payload_summary":{"duration":3}}\n',
        encoding="utf-8",
    )
    monkeypatch.setattr("shortdrama_pipeline.cli.build_runner", lambda *args, **kwargs: failure_runner)

    result = runner.invoke(app, ["failed-summary", failed_job.job_id])

    assert result.exit_code == 0
    assert "失败阶段" in result.output
    assert "响应体" in result.output
    assert "duration invalid" in result.output


def test_cli_cleanup_failed_soft_deletes_run(output_dir, monkeypatch):
    runner = CliRunner()
    pipeline_runner = make_runner(output_dir)
    initial = pipeline_runner.create_job(JobCreate(topic="替嫁新娘逆袭", duration_seconds=60, episode_count=1))
    pipeline_runner.approve_script(initial.job_id)
    pipeline_runner.approve_characters(initial.job_id)

    artifact_store = ArtifactStore(output_dir)
    job_store = JobStore(output_dir / "jobs.sqlite3")
    project_store = ProjectStore(output_dir / "jobs.sqlite3")
    for job in job_store.list_jobs():
        artifact_store.register_job_dir(job.job_id, job.artifact_dir)
    failing_runner = PipelineRunner(
        artifact_store=artifact_store,
        job_store=job_store,
        project_store=project_store,
        script_provider=FakeScriptProvider(),
        image_provider=FakeImageProvider(output_dir),
        video_provider=type(
            "FailingVideoProvider",
            (),
            {"generate_shot_video": staticmethod(lambda *args, **kwargs: (_ for _ in ()).throw(RuntimeError("Seedance 创建任务失败：duration 超限")))},
        )(),
        harness_manager=HarnessManager([]),
        pipeline_logger=PipelineEventLogger(artifact_store),
        model_logger=ModelCallLogger(artifact_store),
    )

    with __import__("pytest").raises(RuntimeError):
        failing_runner.create_job(
            JobCreate(
                topic="继续生成同项目视频",
                duration_seconds=60,
                episode_count=1,
                project_id=initial.project_id,
            )
        )
    failed_job = job_store.list_jobs()[0]
    monkeypatch.setattr("shortdrama_pipeline.cli.build_runner", lambda *args, **kwargs: failing_runner)

    result = runner.invoke(app, ["cleanup-failed", failed_job.job_id])

    assert result.exit_code == 0
    assert "已软删除失败任务" in result.output
    assert any("trash" in line for line in result.output.splitlines())
    with __import__("pytest").raises(KeyError):
        job_store.get_job(failed_job.job_id)
    assert not failed_job.artifact_dir.exists()
    trash_dir = output_dir / "trash" / "projects" / initial.project_id / "runs" / failed_job.job_id
    assert trash_dir.exists()


def test_cli_retry_failed_creates_new_run_for_same_project(output_dir, monkeypatch):
    runner = CliRunner()
    pipeline_runner = make_runner(output_dir)
    initial = pipeline_runner.create_job(JobCreate(topic="替嫁新娘逆袭", duration_seconds=60, episode_count=1))
    pipeline_runner.approve_script(initial.job_id)
    pipeline_runner.approve_characters(initial.job_id)

    artifact_store = ArtifactStore(output_dir)
    job_store = JobStore(output_dir / "jobs.sqlite3")
    project_store = ProjectStore(output_dir / "jobs.sqlite3")
    for job in job_store.list_jobs():
        artifact_store.register_job_dir(job.job_id, job.artifact_dir)
    failing_runner = PipelineRunner(
        artifact_store=artifact_store,
        job_store=job_store,
        project_store=project_store,
        script_provider=FakeScriptProvider(),
        image_provider=FakeImageProvider(output_dir),
        video_provider=type(
            "FailingVideoProvider",
            (),
            {"generate_shot_video": staticmethod(lambda *args, **kwargs: (_ for _ in ()).throw(RuntimeError("Seedance 创建任务失败：duration 超限")))},
        )(),
        harness_manager=HarnessManager([]),
        pipeline_logger=PipelineEventLogger(artifact_store),
        model_logger=ModelCallLogger(artifact_store),
    )
    with __import__("pytest").raises(RuntimeError):
        failing_runner.create_job(
            JobCreate(
                topic="继续生成同项目视频",
                duration_seconds=60,
                episode_count=1,
                project_id=initial.project_id,
            )
        )
    failed_job = job_store.list_jobs()[0]

    retry_runner = make_runner(output_dir)
    for job in retry_runner.job_store.list_jobs():
        retry_runner.artifact_store.register_job_dir(job.job_id, job.artifact_dir)
    monkeypatch.setattr("shortdrama_pipeline.cli.build_runner", lambda *args, **kwargs: retry_runner)

    result = runner.invoke(app, ["retry-failed", failed_job.job_id])

    assert result.exit_code == 0
    assert "任务已重试" in result.output
    latest_job = retry_runner.job_store.list_jobs()[0]
    assert latest_job.job_id != failed_job.job_id
    assert latest_job.project_id == initial.project_id
    assert latest_job.status == JobStatus.COMPLETED
