import json

from shortdrama_pipeline.logging import ModelCallLogger, PipelineEventLogger
from shortdrama_pipeline.models import JobCreate, JobStatus
from shortdrama_pipeline.storage import ArtifactStore, JobStore


def test_artifact_store_creates_job_directory(output_dir):
    store = ArtifactStore(output_dir)
    job_dir = store.create_job_dir("job_abc")

    assert job_dir.exists()
    assert (job_dir / "script").exists()
    assert (job_dir / "characters").exists()
    assert (job_dir / "logs").exists()


def test_artifact_store_writes_json(output_dir):
    store = ArtifactStore(output_dir)
    store.create_job_dir("job_abc")
    path = store.write_json("job_abc", "script/reviewed_script.json", {"标题": "重逢"})

    assert json.loads(path.read_text(encoding="utf-8")) == {"标题": "重逢"}


def test_job_store_creates_and_updates_job(output_dir):
    artifact_store = ArtifactStore(output_dir)
    job_store = JobStore(output_dir / "jobs.sqlite3")
    job = job_store.create_job(
        JobCreate(topic="替嫁新娘逆袭", duration_seconds=60, episode_count=1),
        artifact_store.create_job_dir("job_fixed"),
        job_id="job_fixed",
    )

    assert job.status == JobStatus.CREATED

    updated = job_store.update_status("job_fixed", JobStatus.SCRIPTING)
    assert updated.status == JobStatus.SCRIPTING


def test_model_call_logger_redacts_secret(output_dir):
    store = ArtifactStore(output_dir)
    store.create_job_dir("job_abc")
    logger = ModelCallLogger(store)
    logger.log(
        "job_abc",
        {
            "provider": "seedance",
            "model": "doubao-seedance-2-0-260128",
            "authorization": "Bearer secret-key",
            "prompt_summary": "中文镜头 Prompt",
        },
    )

    content = (output_dir / "job_abc" / "logs" / "model_calls.jsonl").read_text(encoding="utf-8")
    assert "secret-key" not in content
    assert "Bearer [REDACTED]" in content


def test_pipeline_event_logger_writes_jsonl(output_dir):
    store = ArtifactStore(output_dir)
    store.create_job_dir("job_abc")
    logger = PipelineEventLogger(store)
    logger.log("job_abc", "state_changed", {"from": "created", "to": "scripting"})

    line = (output_dir / "job_abc" / "logs" / "pipeline_events.jsonl").read_text(encoding="utf-8")
    assert "state_changed" in line
    assert "scripting" in line
