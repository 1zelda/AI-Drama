from pathlib import Path

from shortdrama_pipeline.config import Settings, load_settings
from shortdrama_pipeline.models import (
    CharacterProfile,
    Episode,
    JobCreate,
    ScriptQualityIssue,
    ScriptQualityReport,
    ProjectSnapshot,
    JobStatus,
    Shot,
)


def test_settings_default_to_local_outputs():
    settings = Settings()

    assert settings.output_dir == Path("outputs")
    assert settings.db_path == Path("outputs/shortdrama.sqlite3")
    assert settings.seed_model == "doubao-seed-2-0-pro-260215"
    assert settings.seedream_model == "doubao-seedream-5-0-260128"
    assert settings.seedance_model == "doubao-seedance-2-0-260128"
    assert settings.seedance_query_base_url == "https://operator.las.cn-beijing.volces.com/api/v1"


def test_load_settings_reads_project_env_file(tmp_path, monkeypatch):
    env_path = tmp_path / ".env"
    env_path.write_text(
        "\n".join(
            [
                "ARK_API_KEY=from-dotenv",
                "SHORTDRAMA_PROVIDER_MODE=ark",
                "SHORTDRAMA_OUTPUT_DIR=custom_outputs",
            ]
        ),
        encoding="utf-8",
    )
    monkeypatch.delenv("ARK_API_KEY", raising=False)
    monkeypatch.delenv("SHORTDRAMA_PROVIDER_MODE", raising=False)
    monkeypatch.delenv("SHORTDRAMA_OUTPUT_DIR", raising=False)

    settings = load_settings(env_file=env_path)

    assert settings.ark_api_key == "from-dotenv"
    assert settings.provider_mode == "ark"
    assert settings.output_dir == tmp_path / "custom_outputs"


def test_job_create_requires_chinese_topic():
    job = JobCreate(
        topic="失忆女总裁在外卖站重逢前夫",
        duration_seconds=120,
        episode_count=2,
        ratio="9:16",
        style="都市情感，强反转",
        notes="每集结尾留悬念",
    )

    assert job.topic.startswith("失忆")
    assert job.ratio == "9:16"


def test_character_profile_keeps_chinese_content():
    profile = CharacterProfile(
        character_id="female_lead",
        name="林晚",
        role="女主",
        age_range="25-30",
        appearance="鹅蛋脸，黑色长发，眼神倔强",
        personality="外柔内刚，遇事冷静",
        costume_style="通勤风白衬衫和深色长裤",
        voice_style="语速稳定，情绪爆发时有压迫感",
        consistency_prompt="始终保持相同五官、发型和年龄感",
    )

    assert profile.name == "林晚"
    assert "相同五官" in profile.consistency_prompt


def test_episode_and_shot_model():
    shot = Shot(
        shot_id="shot_001",
        duration_seconds=8,
        scene_location="医院走廊",
        characters=["female_lead", "male_lead"],
        visual_description="女主推开病房门，发现男主正在签离婚协议。",
        dialogue=["女主：你真的要这么做？", "男主：这是对你最好的选择。"],
        camera="中近景推进，最后停在女主泛红的眼眶。",
        emotion="压抑、委屈、克制",
    )
    episode = Episode(
        episode_id="episode_01",
        title="重逢",
        duration_seconds=60,
        summary="女主在医院意外重逢失联三年的丈夫。",
        hook="男主喊出她失忆前的名字。",
        shots=[shot],
    )

    assert episode.shots[0].shot_id == "shot_001"
    assert JobStatus.SCRIPT_REVIEW_PENDING.value == "script_review_pending"


def test_project_snapshot_keeps_project_and_stage_summary():
    snapshot = ProjectSnapshot(
        project_id="project_20260424_demo",
        title="真假千金互换人生",
        latest_job_id="job_latest",
        latest_job_status="character_review_pending",
        script_status="approved",
        character_status="review_pending",
        video_status="not_started",
        failed_job_count=1,
    )

    assert snapshot.project_id == "project_20260424_demo"
    assert snapshot.script_status == "approved"
    assert snapshot.failed_job_count == 1


def test_script_quality_issue_supports_episode_and_shot_warning_fields():
    issue = ScriptQualityIssue(
        episode_id="episode_02",
        shot_id="shot_005",
        title="情绪转折略突兀",
        detail="角色上一镜头仍在克制，下一镜头直接爆发，铺垫不足。",
        suggestion="在前一镜头补一条迟疑或沉默反应。",
    )

    assert issue.level == "warning"
    assert issue.episode_id == "episode_02"
    assert issue.shot_id == "shot_005"
    assert "铺垫不足" in issue.detail


def test_script_quality_report_keeps_score_warnings_and_recommendation():
    report = ScriptQualityReport(
        job_id="job_20260424_quality",
        overall_score=86.5,
        summary="整体节奏顺畅，人物目标明确，但中段反转铺垫偏弱。",
        episode_warnings={
            "episode_01": ["开场冲突足够，但悬念点可以更集中。"],
            "episode_02": ["中段信息解释偏多，建议压缩说明性对白。"],
        },
        shot_issues=[
            ScriptQualityIssue(
                episode_id="episode_02",
                shot_id="shot_003",
                title="镜头目标重复",
                detail="连续两个镜头都在重复说明男主误会来源，信息增量有限。",
                suggestion="保留冲突更强的一镜，另一镜改为角色动作反馈。",
            )
        ],
        recommendation="优先增强第二集关键转折前的心理铺垫，整体可继续推进，无需阻塞。",
    )

    assert report.job_id == "job_20260424_quality"
    assert report.overall_score == 86.5
    assert report.episode_warnings["episode_01"][0].startswith("开场冲突")
    assert report.shot_issues[0].title == "镜头目标重复"
    assert "无需阻塞" in report.recommendation
