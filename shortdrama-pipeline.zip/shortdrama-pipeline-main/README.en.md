# Shortdrama Pipeline

[中文](README.md) | English

[![CI](https://github.com/drasstry/shortdrama-pipeline/actions/workflows/ci.yml/badge.svg)](https://github.com/drasstry/shortdrama-pipeline/actions/workflows/ci.yml)
![Python](https://img.shields.io/badge/python-3.11%2B-blue)
![Backend First](https://img.shields.io/badge/backend-first-green)
![Chinese Short Drama](https://img.shields.io/badge/Chinese-short--drama-red)

**Shortdrama Pipeline** is a backend automation workflow for Chinese short-drama production. Give it a theme, and it can generate a Chinese script, main character reference images, shot-level videos, and final composed episode videos.

It is not trying to be a full production platform yet. It is a small, runnable, reviewable backend chain that can use real online models today and grow into a web UI, review dashboard, or internal production system later.

## At a Glance

```mermaid
flowchart LR
  A["Topic input\nDuration / Episodes / Style"] --> B["Seed 2.0\nChinese script"]
  B --> C{"Human script review"}
  C -->|Approve| D["Seedream\nOne image per character"]
  C -->|Reject| B
  D --> E{"Human character review"}
  E -->|Approve| F["Seedance 2.0\nShot videos"]
  E -->|Reject| D
  F --> G["ffmpeg\nOrdered composition"]
  G --> H["Episode videos\nproject/latest"]
```

The core rule is simple: **approve the script before generating characters, approve the characters before generating videos.** This avoids spending expensive video credits on the wrong story or the wrong faces.

## Who It Is For

- Developers exploring AI-powered short-drama production chains.
- Content teams testing Chinese short-drama topics, characters, hooks, and reversals.
- Engineering teams integrating Seed, Seedream, and Seedance into a stable backend workflow.
- Product teams that want a CLI/API-first prototype before building a web interface.

## What It Can Do Today

- **Chinese script generation**: use Seed 2.0 to generate a title, character setup, episode outline, and shot list.
- **Script quality checks**: write a warning-only report for shot duration, overloaded actions, overloaded dialogue, and related issues.
- **Human review gates**: scripts and character images have explicit review states.
- **Character image generation**: use Seedream to generate one image per main character.
- **Video generation and composition**: use Seedance 2.0 for shot videos and ffmpeg for final episode composition.
- **Project continuation**: continue an existing project by reusing approved scripts and approved character references.
- **Fake mode**: run the full state machine, CLI, artifacts, and tests without an API key.

## 5-Minute Setup

This is the beginner path from a clean machine to a running local workflow.

### 1. Prepare Your Environment

You need:

- Git
- Python 3.11 or newer
- ffmpeg, required when composing real videos

On macOS:

```bash
brew install git python ffmpeg
```

If you already have Git, Python, and ffmpeg, you can skip this step.

### 2. Clone the Repository

```bash
git clone https://github.com/drasstry/shortdrama-pipeline.git
cd shortdrama-pipeline
```

### 3. Create a Python Virtual Environment

```bash
PYTHON_BIN=$(command -v python3.13 || command -v python3.12 || command -v python3.11 || command -v python3)
$PYTHON_BIN -c 'import sys; assert sys.version_info >= (3, 11), "Python 3.11 or newer is required"'
$PYTHON_BIN -m venv .venv
source .venv/bin/activate
```

When your shell prompt starts with `(.venv)`, the virtual environment is active. If the version check fails on macOS, run `brew install python` and then repeat the commands above.

### 4. Install the Project

```bash
pip install -e ".[dev]"
```

Confirm the CLI is available:

```bash
shortdrama --help
```

### 5. Open the Interactive Menu

```bash
shortdrama shell
```

Then follow the menu:

1. Choose `Create new project/job`
2. Enter a topic, duration, and episode count
3. Review the generated script
4. Approve the script
5. Review the character images
6. Approve the characters
7. Wait for video generation and composition

For your first run, you can skip API configuration and use fake mode. Fake mode does not call online models or consume credits.

## Run Real Online Models

To use real Volcengine Ark models, copy the environment template:

```bash
cp .env.example .env
```

Edit `.env`:

```env
ARK_API_KEY=your-ark-api-key
SHORTDRAMA_PROVIDER_MODE=ark
SHORTDRAMA_OUTPUT_DIR=outputs
SHORTDRAMA_DB_PATH=outputs/shortdrama.sqlite3
ARK_BASE_URL=https://ark.cn-beijing.volces.com/api/v3
```

Run a low-cost smoke test first:

```bash
shortdrama smoke-ark
```

If it passes, start the real workflow:

```bash
shortdrama shell
```

## Common Commands

If you prefer direct commands instead of the menu:

```bash
# Create a job
shortdrama create

# Inspect projects and jobs
shortdrama projects
shortdrama jobs
shortdrama status <job_id>
shortdrama project-dashboard <project_id>
shortdrama project-latest <project_id>

# Review scripts
shortdrama review <job_id>
shortdrama approve-script <job_id>
shortdrama reject-script <job_id> --reason "The reversal is not strong enough"
shortdrama regenerate-script <job_id> --notes "Make the female lead stronger and the first three seconds sharper"

# Review characters
shortdrama approve-characters <job_id>
shortdrama reject-characters <job_id> --reason "Character identity is not clear enough"
shortdrama regenerate-character <job_id> <character_id>

# Continue an existing project
shortdrama continue-project <project_id> --notes "Reuse approved script and characters"

# Handle failed jobs
shortdrama failed-summary <job_id>
shortdrama retry-failed <job_id>
shortdrama cleanup-failed <job_id>
```

## Project States

Use `shortdrama project-dashboard <project_id>` to see where a project is in the pipeline.

Common stages:

- script generating
- script review pending
- script approved
- character generating
- character review pending
- character approved
- video generating
- completed

Only approved scripts and approved characters are copied into `project/latest`. `continue-project` only reuses those confirmed assets.

## Where Outputs Go

The default output directory is `outputs/`:

```text
outputs/
  projects/
    <project_id>/
      latest/
        script/
        characters/
        videos/
      runs/
        <job_id>/
          input.json
          status.json
          script/
          characters/
          shots/
          videos/
          harness/
          logs/
```

`outputs/` is ignored by git because it may contain model outputs, logs, SQLite databases, and video files.

## API Mode

The project also exposes a FastAPI service for future frontends or external workflow systems.

```bash
shortdrama-api
```

Create a job:

```bash
curl -X POST http://127.0.0.1:8000/jobs \
  -H "Content-Type: application/json" \
  -d '{"topic":"替嫁新娘逆袭","duration_seconds":60,"episode_count":1}'
```

## Configuration

Common environment variables:

```env
ARK_API_KEY=your-ark-api-key
SHORTDRAMA_PROVIDER_MODE=auto
SHORTDRAMA_OUTPUT_DIR=outputs
SHORTDRAMA_DB_PATH=outputs/shortdrama.sqlite3
ARK_BASE_URL=https://ark.cn-beijing.volces.com/api/v3
SHORTDRAMA_SEEDANCE_CONCURRENCY=2
SHORTDRAMA_SEEDANCE_POLL_INTERVAL_SECONDS=15
SHORTDRAMA_SEEDANCE_MAX_WAIT_SECONDS=1800
```

`SHORTDRAMA_PROVIDER_MODE` supports:

- `auto`: use Ark when `ARK_API_KEY` exists, otherwise use fake providers.
- `ark`: force online Ark providers and fail if the key is missing.
- `fake`: force local fake providers.

## Development

```bash
source .venv/bin/activate
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 pytest -q
python -m compileall src/shortdrama_pipeline
```

Tests use fake providers by default. They do not call online models.

## Security

Do not commit real API keys. Keep real credentials in your local `.env`; only `.env.example` belongs in the repository.

If a real key appears in chat, screenshots, logs, commits, issues, or pull requests, rotate it in the Volcengine Ark console.

See [SECURITY.md](SECURITY.md) for details.

## Documentation

- Architecture: [中文](docs/ARCHITECTURE.md) / [English](docs/ARCHITECTURE.en.md)
- GitHub upload guide: [中文](docs/GITHUB_UPLOAD.md) / [English](docs/GITHUB_UPLOAD.en.md)
- Security policy: [SECURITY.md](SECURITY.md)

## Current Boundaries

This project focuses on backend automation. It is not a complete SaaS platform yet. It does not currently include:

- multi-user permissions
- a web-based visual editor
- cloud object storage integration
- billing or quota management
- a video timeline editor

Those pieces can be added once the backend state machine is stable.
