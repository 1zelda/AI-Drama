from __future__ import annotations

import shutil
import subprocess
from pathlib import Path


class EpisodeComposer:
    def compose(self, shot_paths: list[Path], output_path: Path) -> Path:
        output_path.parent.mkdir(parents=True, exist_ok=True)
        if not shot_paths:
            raise ValueError("没有可拼接的视频片段")
        if len(shot_paths) == 1:
            shutil.copyfile(shot_paths[0], output_path)
            return output_path

        concat_file = output_path.parent / "concat.txt"
        concat_file.write_text(
            "\n".join(f"file '{path.resolve()}'" for path in shot_paths),
            encoding="utf-8",
        )
        subprocess.run(
            [
                "ffmpeg",
                "-y",
                "-f",
                "concat",
                "-safe",
                "0",
                "-i",
                str(concat_file),
                "-c",
                "copy",
                str(output_path),
            ],
            check=True,
        )
        return output_path
