from __future__ import annotations

import json
import sqlite3
import shutil
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from shortdrama_pipeline.models import JobCreate, JobRecord, JobStatus, ProjectRecord, ProjectSnapshot


class ArtifactStore:
    def __init__(self, output_dir: Path):
        self.output_dir = output_dir
        self._job_dirs: dict[str, Path] = {}

    def create_job_dir(self, job_id: str, project_id: str | None = None) -> Path:
        job_dir = self.output_dir / job_id if project_id is None else self.output_dir / "projects" / project_id / "runs" / job_id
        for relative in ["script", "characters", "shots", "videos", "harness", "logs"]:
            (job_dir / relative).mkdir(parents=True, exist_ok=True)
        self._job_dirs[job_id] = job_dir
        if project_id is not None:
            self.project_latest_dir(project_id).mkdir(parents=True, exist_ok=True)
        return job_dir

    def register_job_dir(self, job_id: str, artifact_dir: Path) -> None:
        self._job_dirs[job_id] = artifact_dir

    def job_dir(self, job_id: str) -> Path:
        if job_id in self._job_dirs:
            return self._job_dirs[job_id]
        direct = self.output_dir / job_id
        if direct.exists():
            self._job_dirs[job_id] = direct
            return direct
        for candidate in (self.output_dir / "projects").glob(f"*/runs/{job_id}"):
            self._job_dirs[job_id] = candidate
            return candidate
        self._job_dirs[job_id] = direct
        return direct

    def project_dir(self, project_id: str) -> Path:
        return self.output_dir / "projects" / project_id

    def project_latest_dir(self, project_id: str) -> Path:
        return self.project_dir(project_id) / "latest"

    def copy_to_project_latest(self, job_id: str, project_id: str, relative_path: str) -> Path:
        source = self.job_dir(job_id) / relative_path
        target = self.project_latest_dir(project_id) / relative_path
        return self._copy_path(source, target)

    def copy_from_project_latest(self, project_id: str, job_id: str, relative_path: str) -> Path:
        source = self.project_latest_dir(project_id) / relative_path
        target = self.job_dir(job_id) / relative_path
        return self._copy_path(source, target)

    def delete_from_project_latest(self, project_id: str, relative_path: str) -> None:
        target = self.project_latest_dir(project_id) / relative_path
        if target.is_dir():
            shutil.rmtree(target)
        elif target.exists():
            target.unlink()

    def _copy_path(self, source: Path, target: Path) -> Path:
        if source.is_dir():
            shutil.copytree(source, target, dirs_exist_ok=True)
            return target
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, target)
        return target

    def write_json(self, job_id: str, relative_path: str, data: Any) -> Path:
        path = self.job_dir(job_id) / relative_path
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        return path

    def read_json(self, job_id: str, relative_path: str) -> Any:
        path = self.job_dir(job_id) / relative_path
        return json.loads(path.read_text(encoding="utf-8"))

    def append_jsonl(self, job_id: str, relative_path: str, data: dict[str, Any]) -> Path:
        path = self.job_dir(job_id) / relative_path
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(data, ensure_ascii=False) + "\n")
        return path

    def soft_delete_job(self, job_id: str) -> Path:
        source = self.job_dir(job_id)
        if not source.exists():
            raise FileNotFoundError(f"任务目录不存在：{job_id}")
        relative = source.relative_to(self.output_dir)
        target = self.output_dir / "trash" / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        if target.exists():
            timestamp = datetime.now(timezone.utc).strftime("%Y%m%d%H%M%S")
            target = target.with_name(f"{target.name}_{timestamp}")
        shutil.move(str(source), str(target))
        self._job_dirs.pop(job_id, None)
        return target


class JobStore:
    def __init__(self, db_path: Path):
        self.db_path = db_path
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._init_db()

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        return conn

    def _init_db(self) -> None:
        with self._connect() as conn:
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS jobs (
                    job_id TEXT PRIMARY KEY,
                    project_id TEXT,
                    status TEXT NOT NULL,
                    topic TEXT NOT NULL,
                    duration_seconds INTEGER NOT NULL,
                    episode_count INTEGER NOT NULL,
                    ratio TEXT NOT NULL,
                    style TEXT NOT NULL,
                    notes TEXT NOT NULL,
                    artifact_dir TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    failed_phase TEXT,
                    last_error TEXT
                )
                """
            )
            columns = {row["name"] for row in conn.execute("PRAGMA table_info(jobs)").fetchall()}
            if "project_id" not in columns:
                conn.execute("ALTER TABLE jobs ADD COLUMN project_id TEXT")

    def create_job(self, request: JobCreate, artifact_dir: Path, job_id: str | None = None) -> JobRecord:
        now = datetime.now(timezone.utc)
        job = JobRecord(
            job_id=job_id or f"job_{now.strftime('%Y%m%d')}_{uuid.uuid4().hex[:8]}",
            project_id=request.project_id,
            status=JobStatus.CREATED,
            topic=request.topic,
            duration_seconds=request.duration_seconds,
            episode_count=request.episode_count,
            ratio=request.ratio,
            style=request.style,
            notes=request.notes,
            artifact_dir=artifact_dir,
            created_at=now,
            updated_at=now,
        )
        with self._connect() as conn:
            conn.execute(
                """
                INSERT INTO jobs (
                    job_id, project_id, status, topic, duration_seconds, episode_count, ratio, style,
                    notes, artifact_dir, created_at, updated_at, failed_phase, last_error
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    job.job_id,
                    job.project_id,
                    job.status.value,
                    job.topic,
                    job.duration_seconds,
                    job.episode_count,
                    job.ratio,
                    job.style,
                    job.notes,
                    str(job.artifact_dir),
                    job.created_at.isoformat(),
                    job.updated_at.isoformat(),
                    job.failed_phase,
                    job.last_error,
                ),
            )
        return job

    def get_job(self, job_id: str) -> JobRecord:
        with self._connect() as conn:
            row = conn.execute("SELECT * FROM jobs WHERE job_id = ?", (job_id,)).fetchone()
        if row is None:
            raise KeyError(f"任务不存在：{job_id}")
        return self._row_to_job(row)

    def list_jobs(self, project_id: str | None = None, status: JobStatus | None = None) -> list[JobRecord]:
        query = "SELECT * FROM jobs"
        clauses: list[str] = []
        params: list[str] = []
        if project_id is not None:
            clauses.append("project_id = ?")
            params.append(project_id)
        if status is not None:
            clauses.append("status = ?")
            params.append(status.value)
        if clauses:
            query += " WHERE " + " AND ".join(clauses)
        query += " ORDER BY created_at DESC"
        with self._connect() as conn:
            rows = conn.execute(query, params).fetchall()
        return [self._row_to_job(row) for row in rows]

    def delete_job(self, job_id: str) -> None:
        with self._connect() as conn:
            conn.execute("DELETE FROM jobs WHERE job_id = ?", (job_id,))

    def update_status(
        self,
        job_id: str,
        status: JobStatus,
        failed_phase: str | None = None,
        last_error: str | None = None,
    ) -> JobRecord:
        now = datetime.now(timezone.utc).isoformat()
        with self._connect() as conn:
            conn.execute(
                """
                UPDATE jobs
                SET status = ?, updated_at = ?, failed_phase = ?, last_error = ?
                WHERE job_id = ?
                """,
                (status.value, now, failed_phase, last_error, job_id),
            )
        return self.get_job(job_id)

    def _row_to_job(self, row: sqlite3.Row) -> JobRecord:
        return JobRecord(
            job_id=row["job_id"],
            project_id=row["project_id"],
            status=JobStatus(row["status"]),
            topic=row["topic"],
            duration_seconds=row["duration_seconds"],
            episode_count=row["episode_count"],
            ratio=row["ratio"],
            style=row["style"],
            notes=row["notes"],
            artifact_dir=Path(row["artifact_dir"]),
            created_at=datetime.fromisoformat(row["created_at"]),
            updated_at=datetime.fromisoformat(row["updated_at"]),
            failed_phase=row["failed_phase"],
            last_error=row["last_error"],
        )


class ProjectStore:
    def __init__(self, db_path: Path):
        self.db_path = db_path
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._init_db()

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        return conn

    def _init_db(self) -> None:
        with self._connect() as conn:
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS projects (
                    project_id TEXT PRIMARY KEY,
                    title TEXT NOT NULL,
                    latest_job_id TEXT,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                )
                """
            )

    def create_project(self, title: str, project_id: str | None = None) -> ProjectRecord:
        now = datetime.now(timezone.utc)
        project = ProjectRecord(
            project_id=project_id or f"project_{now.strftime('%Y%m%d')}_{uuid.uuid4().hex[:8]}",
            title=title,
            created_at=now,
            updated_at=now,
        )
        with self._connect() as conn:
            conn.execute(
                """
                INSERT INTO projects (project_id, title, latest_job_id, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?)
                """,
                (
                    project.project_id,
                    project.title,
                    project.latest_job_id,
                    project.created_at.isoformat(),
                    project.updated_at.isoformat(),
                ),
            )
        return project

    def get_project(self, project_id: str) -> ProjectRecord:
        with self._connect() as conn:
            row = conn.execute("SELECT * FROM projects WHERE project_id = ?", (project_id,)).fetchone()
        if row is None:
            raise KeyError(f"项目不存在：{project_id}")
        return self._row_to_project(row)

    def list_projects(self) -> list[ProjectRecord]:
        with self._connect() as conn:
            rows = conn.execute("SELECT * FROM projects ORDER BY created_at DESC").fetchall()
        return [self._row_to_project(row) for row in rows]

    def update_latest_job(self, project_id: str, job_id: str) -> ProjectRecord:
        return self.set_latest_job(project_id, job_id)

    def set_latest_job(self, project_id: str, job_id: str | None) -> ProjectRecord:
        now = datetime.now(timezone.utc).isoformat()
        with self._connect() as conn:
            conn.execute(
                """
                UPDATE projects
                SET latest_job_id = ?, updated_at = ?
                WHERE project_id = ?
                """,
                (job_id, now, project_id),
            )
        return self.get_project(project_id)

    def project_snapshot(self, project_id: str, job_store: JobStore) -> ProjectSnapshot:
        project = self.get_project(project_id)
        jobs = job_store.list_jobs(project_id=project_id)
        latest = next((job for job in jobs if job.status != JobStatus.FAILED), jobs[0] if jobs else None)
        failed_job_count = sum(1 for job in jobs if job.status == JobStatus.FAILED)

        script_status = "not_started"
        character_status = "not_started"
        video_status = "not_started"
        if latest is not None:
            if latest.status == JobStatus.SCRIPT_REVIEW_PENDING:
                script_status = "review_pending"
            elif latest.status in {
                JobStatus.SCRIPT_APPROVED,
                JobStatus.CHARACTER_DESIGNING,
                JobStatus.CHARACTER_REVIEW_PENDING,
                JobStatus.CHARACTER_APPROVED,
                JobStatus.SHOT_PLANNING,
                JobStatus.VIDEO_GENERATING,
                JobStatus.COMPOSING,
                JobStatus.COMPLETED,
            }:
                script_status = "approved"

            if latest.status == JobStatus.CHARACTER_REVIEW_PENDING:
                character_status = "review_pending"
            elif latest.status in {
                JobStatus.CHARACTER_APPROVED,
                JobStatus.SHOT_PLANNING,
                JobStatus.VIDEO_GENERATING,
                JobStatus.COMPOSING,
                JobStatus.COMPLETED,
            }:
                character_status = "approved"

            if latest.status == JobStatus.VIDEO_GENERATING:
                video_status = "generating"
            elif latest.status == JobStatus.COMPOSING:
                video_status = "composing"
            elif latest.status == JobStatus.COMPLETED:
                video_status = "completed"
            elif latest.status == JobStatus.FAILED and latest.failed_phase == JobStatus.VIDEO_GENERATING.value:
                video_status = "failed"

        return ProjectSnapshot(
            project_id=project.project_id,
            title=project.title,
            latest_job_id=latest.job_id if latest else None,
            latest_job_status=latest.status.value if latest else None,
            script_status=script_status,
            character_status=character_status,
            video_status=video_status,
            failed_job_count=failed_job_count,
        )

    def _row_to_project(self, row: sqlite3.Row) -> ProjectRecord:
        return ProjectRecord(
            project_id=row["project_id"],
            title=row["title"],
            latest_job_id=row["latest_job_id"],
            created_at=datetime.fromisoformat(row["created_at"]),
            updated_at=datetime.fromisoformat(row["updated_at"]),
        )
