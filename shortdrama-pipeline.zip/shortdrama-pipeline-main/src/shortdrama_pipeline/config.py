from __future__ import annotations

import os
from pathlib import Path

from pydantic import BaseModel, Field, field_validator


class Settings(BaseModel):
    output_dir: Path = Field(default=Path("outputs"))
    db_path: Path = Field(default=Path("outputs/shortdrama.sqlite3"))
    ark_api_key: str | None = None
    ark_base_url: str = "https://ark.cn-beijing.volces.com/api/v3"
    seedance_query_base_url: str = "https://operator.las.cn-beijing.volces.com/api/v1"
    seed_model: str = "doubao-seed-2-0-pro-260215"
    seedream_model: str = "doubao-seedream-5-0-260128"
    seedance_model: str = "doubao-seedance-2-0-260128"
    provider_mode: str = "auto"
    seedance_concurrency: int = 2
    seedance_poll_interval_seconds: int = 15
    seedance_max_wait_seconds: int = 1800

    @field_validator("seedance_concurrency")
    @classmethod
    def clamp_seedance_concurrency(cls, value: int) -> int:
        if value < 1:
            return 1
        if value > 5:
            return 5
        return value

    @field_validator("seedance_poll_interval_seconds", "seedance_max_wait_seconds")
    @classmethod
    def clamp_seedance_polling_seconds(cls, value: int) -> int:
        if value < 1:
            return 1
        return value


def _read_env_file(env_file: Path) -> dict[str, str]:
    if not env_file.exists():
        return {}

    values: dict[str, str] = {}
    for raw_line in env_file.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        values[key.strip()] = value.strip().strip('"').strip("'")
    return values


def _setting_value(name: str, env_values: dict[str, str], default: str) -> str:
    return os.getenv(name) or env_values.get(name) or default


def _path_from_setting(value: str, env_file: Path | None) -> Path:
    path = Path(value)
    if env_file is not None and not path.is_absolute():
        return env_file.parent / path
    return path


def load_settings(env_file: Path | None = None) -> Settings:
    selected_env_file = env_file or Path(".env")
    env_values = _read_env_file(selected_env_file)
    output_dir = _path_from_setting(
        _setting_value("SHORTDRAMA_OUTPUT_DIR", env_values, "outputs"),
        env_file,
    )
    db_path = _path_from_setting(
        _setting_value("SHORTDRAMA_DB_PATH", env_values, str(output_dir / "shortdrama.sqlite3")),
        env_file,
    )
    return Settings(
        output_dir=output_dir,
        db_path=db_path,
        ark_api_key=os.getenv("ARK_API_KEY") or env_values.get("ARK_API_KEY"),
        ark_base_url=_setting_value("ARK_BASE_URL", env_values, "https://ark.cn-beijing.volces.com/api/v3"),
        seedance_query_base_url=_setting_value(
            "SEEDANCE_QUERY_BASE_URL",
            env_values,
            "https://operator.las.cn-beijing.volces.com/api/v1",
        ),
        provider_mode=_setting_value("SHORTDRAMA_PROVIDER_MODE", env_values, "auto"),
        seedance_concurrency=int(_setting_value("SHORTDRAMA_SEEDANCE_CONCURRENCY", env_values, "2")),
        seedance_poll_interval_seconds=int(
            _setting_value("SHORTDRAMA_SEEDANCE_POLL_INTERVAL_SECONDS", env_values, "15")
        ),
        seedance_max_wait_seconds=int(_setting_value("SHORTDRAMA_SEEDANCE_MAX_WAIT_SECONDS", env_values, "1800")),
    )
