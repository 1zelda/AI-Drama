from __future__ import annotations

import json
import shutil
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Protocol

import httpx
from openai import OpenAI

from shortdrama_pipeline.config import Settings
from shortdrama_pipeline.logging import ModelCallLogger
from shortdrama_pipeline.models import (
    CharacterImage,
    CharacterProfile,
    Episode,
    JobCreate,
    ScriptBundle,
    Shot,
    VideoResult,
)
from shortdrama_pipeline.prompts import build_character_prompt, build_script_prompt


def _extract_json_object(text: str) -> dict:
    cleaned = text.strip()
    if cleaned.startswith("```"):
        cleaned = cleaned.removeprefix("```json").removeprefix("```").removesuffix("```").strip()
    start = cleaned.find("{")
    end = cleaned.rfind("}")
    if start == -1 or end == -1 or end < start:
        raise ValueError("模型响应中没有找到 JSON 对象")
    return json.loads(cleaned[start : end + 1])


def normalize_script_data(data: dict) -> ScriptBundle:
    normalized = dict(data)
    normalized["characters"] = [dict(character) for character in normalized.get("characters", [])]
    for character in normalized["characters"]:
        character["character_id"] = str(character.get("character_id", ""))

    normalized["episodes"] = [dict(episode) for episode in normalized.get("episodes", [])]
    for episode in normalized["episodes"]:
        episode["episode_id"] = str(episode.get("episode_id", ""))
        episode["shots"] = [dict(shot) for shot in episode.get("shots", [])]
        for shot in episode["shots"]:
            shot["shot_id"] = str(shot.get("shot_id", ""))
            shot["characters"] = [str(character_id) for character_id in shot.get("characters", [])]
            dialogue = shot.get("dialogue", [])
            if isinstance(dialogue, str):
                shot["dialogue"] = [dialogue]
            elif dialogue is None:
                shot["dialogue"] = []
            else:
                shot["dialogue"] = [str(line) for line in dialogue]

    return ScriptBundle.model_validate(normalized)


class ScriptProvider(Protocol):
    def generate_script(self, job_id: str, request: JobCreate) -> ScriptBundle:
        raise NotImplementedError


class ImageProvider(Protocol):
    def generate_character_image(self, job_id: str, profile: CharacterProfile, output_dir: str) -> CharacterImage:
        raise NotImplementedError


class VideoProvider(Protocol):
    def generate_shot_video(self, job_id: str, episode_id: str, shot: Shot, output_dir: str | None = None) -> VideoResult:
        raise NotImplementedError


class FakeScriptProvider:
    def __init__(self, model_logger: ModelCallLogger | None = None):
        self.model_logger = model_logger
        self.call_count = 0

    def generate_script(self, job_id: str, request: JobCreate) -> ScriptBundle:
        self.call_count += 1
        female = CharacterProfile(
            character_id="female_lead",
            name="林晚",
            role="女主",
            age_range="25-30",
            appearance="黑色长发，五官清冷，眼神倔强",
            personality="外柔内刚，关键时刻果断",
            costume_style="都市通勤风白衬衫和深色长裤",
            voice_style="清晰坚定，情绪爆发时有压迫感",
            consistency_prompt="始终保持相同五官、脸型、发型、年龄感和都市通勤风格",
        )
        male = CharacterProfile(
            character_id="male_lead",
            name="沈砚",
            role="男主",
            age_range="28-35",
            appearance="短发，轮廓清晰，表情克制",
            personality="冷静强势，内心有隐痛",
            costume_style="深色西装，简洁高级",
            voice_style="低沉克制",
            consistency_prompt="始终保持相同五官、短发、成熟年龄感和深色西装风格",
        )
        shot = Shot(
            shot_id="shot_001",
            duration_seconds=min(8, request.duration_seconds),
            scene_location="医院走廊",
            characters=["female_lead", "male_lead"],
            visual_description="女主推开病房门，发现男主正在签一份离婚协议。",
            dialogue=["女主：你真的要这么做？", "男主：这是对你最好的选择。"],
            camera="中近景推进，最后停在女主泛红的眼眶。",
            emotion="压抑、委屈、克制",
        )
        episode = Episode(
            episode_id="episode_01",
            title="重逢",
            duration_seconds=request.duration_seconds,
            summary="女主在医院重逢失联三年的丈夫，却发现对方准备切断关系。",
            hook="男主喊出女主失忆前的名字。",
            shots=[shot],
        )
        script = ScriptBundle(
            series_title=request.topic,
            series_bible="这是一部中文短剧测试剧本，主打都市情感、强冲突和强反转。",
            characters=[female, male],
            episodes=[episode],
        )
        if self.model_logger is not None:
            self.model_logger.log(
                job_id,
                {
                    "provider": "fake_seed",
                    "model": "fake-seed-2.0",
                    "operation": "generate_script",
                    "topic": request.topic,
                    "episode_count": request.episode_count,
                    "repair_used": False,
                },
            )
        return script


class FakeImageProvider:
    def __init__(self, base_dir: Path, model_logger: ModelCallLogger | None = None):
        self.base_dir = base_dir
        self.model_logger = model_logger
        self.call_count = 0

    def generate_character_image(self, job_id: str, profile: CharacterProfile, output_dir: str) -> CharacterImage:
        self.call_count += 1
        target_dir = Path(output_dir)
        target_dir.mkdir(parents=True, exist_ok=True)
        image_path = target_dir / "image_01.png"
        image_path.write_bytes(b"fake image bytes")
        approved_path = target_dir / "approved.png"
        shutil.copyfile(image_path, approved_path)
        if self.model_logger is not None:
            self.model_logger.log(
                job_id,
                {
                    "provider": "fake_seedream",
                    "model": "fake-seedream",
                    "operation": "generate_character_image",
                    "character_id": profile.character_id,
                    "character_name": profile.name,
                    "image_url": approved_path.resolve().as_uri(),
                },
            )
        return CharacterImage(
            character_id=profile.character_id,
            prompt=build_character_prompt(profile),
            image_path=str(image_path),
            source_url=image_path.resolve().as_uri(),
            approved_path=str(approved_path),
            approved_url=approved_path.resolve().as_uri(),
        )


class FakeVideoProvider:
    def __init__(self, base_dir: Path, model_logger: ModelCallLogger | None = None):
        self.base_dir = base_dir
        self.model_logger = model_logger

    def generate_shot_video(self, job_id: str, episode_id: str, shot: Shot, output_dir: str | None = None) -> VideoResult:
        video_root = Path(output_dir) if output_dir is not None else self.base_dir / job_id
        video_dir = video_root / "videos" / episode_id
        video_dir.mkdir(parents=True, exist_ok=True)
        video_path = video_dir / f"{shot.shot_id}.mp4"
        video_path.write_bytes(b"fake video bytes")
        task_id = f"fake_seedance_{shot.shot_id}"
        video_url = video_path.resolve().as_uri()
        if self.model_logger is not None:
            self.model_logger.log(
                job_id,
                {
                    "provider": "fake_seedance",
                    "model": "fake-seedance-2.0",
                    "operation": "seedance_create_task",
                    "episode_id": episode_id,
                    "shot_id": shot.shot_id,
                    "task_id": task_id,
                },
            )
            self.model_logger.log(
                job_id,
                {
                    "provider": "fake_seedance",
                    "model": "fake-seedance-2.0",
                    "operation": "seedance_poll_status",
                    "task_id": task_id,
                    "status": "succeeded",
                },
            )
            self.model_logger.log(
                job_id,
                {
                    "provider": "fake_seedance",
                    "model": "fake-seedance-2.0",
                    "operation": "seedance_download_video",
                    "task_id": task_id,
                    "video_url": video_url,
                    "video_path": str(video_path),
                },
            )
        return VideoResult(
            episode_id=episode_id,
            shot_id=shot.shot_id,
            task_id=task_id,
            video_path=str(video_path),
        )


class ArkScriptProvider:
    def __init__(self, settings: Settings, model_logger: ModelCallLogger | None = None):
        if not settings.ark_api_key:
            raise ValueError("缺少 ARK_API_KEY")
        self.settings = settings
        self.model_logger = model_logger
        self.client = OpenAI(base_url=settings.ark_base_url, api_key=settings.ark_api_key)

    def generate_script(self, job_id: str, request: JobCreate) -> ScriptBundle:
        prompt = build_script_prompt(
            topic=request.topic,
            duration_seconds=request.duration_seconds,
            episode_count=request.episode_count,
            ratio=request.ratio,
            style=request.style,
            notes=request.notes,
        )
        raw_text = self._request_script_text(prompt)
        self._log_script_raw_response(job_id, raw_text, stage="initial")
        try:
            script = normalize_script_data(_extract_json_object(raw_text))
            self._log_script_success(job_id, request, repair_used=False)
            return script
        except (json.JSONDecodeError, ValueError) as exc:
            self._log_script_parse_failure(job_id, raw_text, exc, stage="initial")
            repaired_text = self._request_script_text(self._build_repair_prompt(raw_text))
            self._log_script_raw_response(job_id, repaired_text, stage="repair")
            try:
                script = normalize_script_data(_extract_json_object(repaired_text))
                self._log_script_success(job_id, request, repair_used=True)
                return script
            except (json.JSONDecodeError, ValueError) as repair_exc:
                self._log_script_parse_failure(job_id, repaired_text, repair_exc, stage="repair")
                raise repair_exc

    def _request_script_text(self, prompt: str) -> str:
        response = self.client.responses.create(
            model=self.settings.seed_model,
            input=[{"role": "user", "content": [{"type": "input_text", "text": prompt}]}],
        )
        return response.output_text

    def _build_repair_prompt(self, raw_text: str) -> str:
        return (
            "下面是一段本应为严格 JSON 的中文短剧脚本输出，但格式损坏了。"
            "请在不改变字段结构和中文语义的前提下，修复成严格 JSON。"
            "只输出一个 JSON 对象，不要输出 Markdown，不要解释。\n\n"
            f"{raw_text}"
        )

    def _log_script_raw_response(self, job_id: str, raw_text: str, stage: str) -> None:
        if self.model_logger is not None:
            self.model_logger.log(
                job_id,
                {
                    "provider": "ark_seed",
                    "model": self.settings.seed_model,
                    "operation": "generate_script_raw_response",
                    "stage": stage,
                    "raw_output": raw_text,
                },
            )

    def _log_script_parse_failure(self, job_id: str, raw_text: str, exc: Exception, stage: str) -> None:
        if self.model_logger is not None:
            self.model_logger.log(
                job_id,
                {
                    "provider": "ark_seed",
                    "model": self.settings.seed_model,
                    "operation": "generate_script_parse_failed",
                    "stage": stage,
                    "error": str(exc),
                    "raw_output": raw_text,
                },
            )

    def _log_script_success(self, job_id: str, request: JobCreate, repair_used: bool) -> None:
        if self.model_logger is not None:
            self.model_logger.log(
                job_id,
                {
                    "provider": "ark_seed",
                    "model": self.settings.seed_model,
                    "operation": "generate_script",
                    "topic": request.topic,
                    "episode_count": request.episode_count,
                    "repair_used": repair_used,
                },
            )


class ArkImageProvider:
    def __init__(self, settings: Settings, model_logger: ModelCallLogger | None = None):
        if not settings.ark_api_key:
            raise ValueError("缺少 ARK_API_KEY")
        self.settings = settings
        self.model_logger = model_logger
        self.client = OpenAI(base_url=settings.ark_base_url, api_key=settings.ark_api_key)

    def generate_character_image(self, job_id: str, profile: CharacterProfile, output_dir: str) -> CharacterImage:
        prompt = build_character_prompt(profile)
        response = self.client.images.generate(
            model=self.settings.seedream_model,
            prompt=prompt,
            size="2K",
            response_format="url",
            extra_body={"watermark": False},
        )
        image_url = response.data[0].url
        target_dir = Path(output_dir)
        target_dir.mkdir(parents=True, exist_ok=True)
        image_path = target_dir / "image_01.png"
        with httpx.stream("GET", image_url, timeout=120) as stream:
            stream.raise_for_status()
            with image_path.open("wb") as handle:
                for chunk in stream.iter_bytes():
                    handle.write(chunk)
        approved_path = target_dir / "approved.png"
        shutil.copyfile(image_path, approved_path)
        if self.model_logger is not None:
            self.model_logger.log(
                job_id,
                {
                    "provider": "ark_seedream",
                    "model": self.settings.seedream_model,
                    "operation": "generate_character_image",
                    "character_id": profile.character_id,
                    "character_name": profile.name,
                    "image_url": image_url,
                },
            )
        return CharacterImage(
            character_id=profile.character_id,
            prompt=prompt,
            image_path=str(image_path),
            source_url=image_url,
            approved_path=str(approved_path),
            approved_url=image_url,
        )


class ArkSeedanceProvider:
    def __init__(self, settings: Settings, model_logger: ModelCallLogger | None = None):
        if not settings.ark_api_key:
            raise ValueError("缺少 ARK_API_KEY")
        self.settings = settings
        self.model_logger = model_logger
        self.client = httpx.Client(timeout=120)

    def generate_shot_video(self, job_id: str, episode_id: str, shot: Shot, output_dir: str | None = None) -> VideoResult:
        payload = {
            "model": self.settings.seedance_model,
            "content": [{"type": "text", "text": shot.seedance_prompt}],
            "generate_audio": True,
            "ratio": "9:16",
            "duration": shot.duration_seconds,
            "watermark": False,
        }
        for image_url in shot.reference_images:
            if not image_url.startswith(("http://", "https://")):
                raise ValueError("真实 Seedance 调用需要公网可访问的参考图 URL；当前参考图只有本地路径")
            payload["content"].append(
                {"type": "image_url", "image_url": {"url": image_url}, "role": "reference_image"}
            )
        response = self.client.post(
            f"{self.settings.ark_base_url}/contents/generations/tasks",
            headers={"Authorization": f"Bearer {self.settings.ark_api_key}", "Content-Type": "application/json"},
            json=payload,
        )
        if response.is_error:
            if self.model_logger is not None:
                self.model_logger.log(
                    job_id,
                    {
                        "provider": "ark_seedance",
                        "model": self.settings.seedance_model,
                        "operation": "seedance_create_task_failed",
                        "episode_id": episode_id,
                        "shot_id": shot.shot_id,
                        "response_status": response.status_code,
                        "response_body": response.text,
                        "payload_summary": {
                            "duration": payload["duration"],
                            "ratio": payload["ratio"],
                            "generate_audio": payload["generate_audio"],
                            "reference_image_count": len(shot.reference_images),
                        },
                    },
                )
            response.raise_for_status()
        task_id = response.json()["id"]
        if self.model_logger is not None:
            self.model_logger.log(
                job_id,
                {
                    "provider": "ark_seedance",
                    "model": self.settings.seedance_model,
                    "operation": "seedance_create_task",
                    "episode_id": episode_id,
                    "shot_id": shot.shot_id,
                    "task_id": task_id,
                },
            )
        video_url = self._wait_for_video_url(job_id, task_id)
        video_root = Path(output_dir) if output_dir is not None else self.settings.output_dir / job_id
        video_dir = video_root / "videos" / episode_id
        video_dir.mkdir(parents=True, exist_ok=True)
        video_path = video_dir / f"{shot.shot_id}.mp4"
        with self.client.stream("GET", video_url) as stream:
            stream.raise_for_status()
            with video_path.open("wb") as handle:
                for chunk in stream.iter_bytes():
                    handle.write(chunk)
        if self.model_logger is not None:
            self.model_logger.log(
                job_id,
                {
                    "provider": "ark_seedance",
                    "model": self.settings.seedance_model,
                    "operation": "seedance_download_video",
                    "task_id": task_id,
                    "video_url": video_url,
                    "video_path": str(video_path),
                },
            )
        return VideoResult(episode_id=episode_id, shot_id=shot.shot_id, task_id=task_id, video_path=str(video_path))

    def _wait_for_video_url(self, job_id: str, task_id: str) -> str:
        deadline = time.monotonic() + self.settings.seedance_max_wait_seconds
        while True:
            data = self._fetch_task_status(task_id)
            status = data.get("status")
            if self.model_logger is not None:
                self.model_logger.log(
                    job_id,
                    {
                        "provider": "ark_seedance",
                        "model": self.settings.seedance_model,
                        "operation": "seedance_poll_status",
                        "task_id": task_id,
                        "status": status,
                    },
                )
            if status == "succeeded":
                content = data.get("content", {})
                video_url = content.get("video_url")
                if not video_url:
                    raise ValueError(f"Seedance 任务成功但缺少 video_url：{task_id}")
                return video_url
            if status in {"failed", "expired", "cancelled"}:
                raise RuntimeError(f"Seedance 任务失败：{task_id}，状态：{status}，响应：{data}")
            remaining_seconds = deadline - time.monotonic()
            if remaining_seconds <= 0:
                break
            time.sleep(min(self.settings.seedance_poll_interval_seconds, remaining_seconds))
        raise TimeoutError(f"Seedance 任务超时：{task_id}")

    def _fetch_task_status(self, task_id: str) -> dict:
        last_error: Exception | None = None
        for url in self._task_status_urls(task_id):
            response = self.client.get(
                url,
                headers={"Authorization": f"Bearer {self.settings.ark_api_key}"},
            )
            if response.status_code in {401, 404}:
                last_error = httpx.HTTPStatusError(
                    f"查询任务失败：{response.status_code}",
                    request=response.request,
                    response=response,
                )
                continue
            response.raise_for_status()
            return response.json()
        if last_error is not None:
            raise last_error
        raise RuntimeError(f"查询 Seedance 任务失败：{task_id}")

    def _task_status_urls(self, task_id: str) -> list[str]:
        return [
            f"{self.settings.seedance_query_base_url}/contents/generations/tasks/{task_id}",
            f"{self.settings.ark_base_url}/contents/generations/tasks/{task_id}",
        ]


@dataclass
class ProviderBundle:
    script: ScriptProvider
    image: ImageProvider
    video: VideoProvider


class ArkProviderFactory:
    def __init__(self, settings: Settings, model_logger: ModelCallLogger | None = None):
        self.settings = settings
        self.model_logger = model_logger

    def create(self, fake_when_missing_key: bool = True) -> ProviderBundle:
        if self.settings.provider_mode == "fake":
            return ProviderBundle(
                script=FakeScriptProvider(model_logger=self.model_logger),
                image=FakeImageProvider(self.settings.output_dir, model_logger=self.model_logger),
                video=FakeVideoProvider(self.settings.output_dir, model_logger=self.model_logger),
            )
        if self.settings.provider_mode == "ark" and not self.settings.ark_api_key:
            raise ValueError("缺少 ARK_API_KEY")
        if fake_when_missing_key and not self.settings.ark_api_key:
            return ProviderBundle(
                script=FakeScriptProvider(model_logger=self.model_logger),
                image=FakeImageProvider(self.settings.output_dir, model_logger=self.model_logger),
                video=FakeVideoProvider(self.settings.output_dir, model_logger=self.model_logger),
            )
        return ProviderBundle(
            script=ArkScriptProvider(self.settings, model_logger=self.model_logger),
            image=ArkImageProvider(self.settings, model_logger=self.model_logger),
            video=ArkSeedanceProvider(self.settings, model_logger=self.model_logger),
        )
