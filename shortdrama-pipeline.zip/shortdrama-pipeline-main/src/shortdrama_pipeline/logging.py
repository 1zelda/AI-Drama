from __future__ import annotations

from datetime import datetime, timezone
from typing import Any

from shortdrama_pipeline.storage import ArtifactStore


def _redact(value: Any) -> Any:
    if isinstance(value, dict):
        redacted = {}
        for key, child in value.items():
            if key.lower() == "authorization":
                redacted[key] = "Bearer [REDACTED]"
            elif key.lower() in {"api_key", "ark_api_key"}:
                redacted[key] = "[REDACTED]"
            else:
                redacted[key] = _redact(child)
        return redacted
    if isinstance(value, list):
        return [_redact(item) for item in value]
    return value


class PipelineEventLogger:
    def __init__(self, artifact_store: ArtifactStore):
        self.artifact_store = artifact_store

    def log(self, job_id: str, event: str, payload: dict[str, Any]) -> None:
        self.artifact_store.append_jsonl(
            job_id,
            "logs/pipeline_events.jsonl",
            {
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "event": event,
                "payload": payload,
            },
        )


class ModelCallLogger:
    def __init__(self, artifact_store: ArtifactStore):
        self.artifact_store = artifact_store

    def log(self, job_id: str, payload: dict[str, Any]) -> None:
        self.artifact_store.append_jsonl(
            job_id,
            "logs/model_calls.jsonl",
            {
                "timestamp": datetime.now(timezone.utc).isoformat(),
                **_redact(payload),
            },
        )
