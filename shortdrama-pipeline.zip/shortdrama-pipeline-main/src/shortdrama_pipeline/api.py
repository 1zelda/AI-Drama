from __future__ import annotations

from pathlib import Path

import uvicorn
from fastapi import FastAPI

from shortdrama_pipeline.config import load_settings
from shortdrama_pipeline.harness import HarnessManager
from shortdrama_pipeline.logging import ModelCallLogger, PipelineEventLogger
from shortdrama_pipeline.models import JobCreate
from shortdrama_pipeline.pipeline import PipelineRunner
from shortdrama_pipeline.providers import ArkProviderFactory
from shortdrama_pipeline.storage import ArtifactStore, JobStore, ProjectStore


def build_runner(output_dir: Path | None = None) -> PipelineRunner:
    settings = load_settings()
    if output_dir is not None:
        settings.output_dir = output_dir
        settings.db_path = output_dir / "jobs.sqlite3"
    root = settings.output_dir
    artifact_store = ArtifactStore(root)
    job_store = JobStore(settings.db_path)
    project_store = ProjectStore(settings.db_path)
    for job in job_store.list_jobs():
        artifact_store.register_job_dir(job.job_id, job.artifact_dir)
    model_logger = ModelCallLogger(artifact_store)
    providers = ArkProviderFactory(settings, model_logger=model_logger).create(fake_when_missing_key=True)
    return PipelineRunner(
        artifact_store=artifact_store,
        job_store=job_store,
        project_store=project_store,
        script_provider=providers.script,
        image_provider=providers.image,
        video_provider=providers.video,
        harness_manager=HarnessManager([]),
        pipeline_logger=PipelineEventLogger(artifact_store),
        model_logger=model_logger,
        settings=settings,
    )


def create_app(output_dir: Path | None = None) -> FastAPI:
    app = FastAPI(title="中文短剧生产流水线")
    runner = build_runner(output_dir)

    @app.post("/jobs")
    def create_job(request: JobCreate):
        return runner.create_job(request).model_dump(mode="json")

    @app.get("/jobs")
    def list_jobs():
        return [job.model_dump(mode="json") for job in runner.job_store.list_jobs()]

    @app.get("/jobs/{job_id}")
    def get_job(job_id: str):
        return runner.job_store.get_job(job_id).model_dump(mode="json")

    @app.get("/jobs/{job_id}/artifacts")
    def get_artifacts(job_id: str):
        job = runner.job_store.get_job(job_id)
        return {"job_id": job_id, "artifact_dir": str(job.artifact_dir)}

    @app.post("/jobs/{job_id}/continue")
    def continue_job(job_id: str):
        return runner.continue_job(job_id).model_dump(mode="json")

    @app.post("/jobs/{job_id}/cancel")
    def cancel_job(job_id: str):
        return runner.cancel_job(job_id).model_dump(mode="json")

    @app.post("/jobs/{job_id}/script/approve")
    def approve_script(job_id: str):
        return runner.approve_script(job_id).model_dump(mode="json")

    @app.post("/jobs/{job_id}/characters/approve")
    def approve_characters(job_id: str):
        return runner.approve_characters(job_id).model_dump(mode="json")

    return app


app = create_app()


def main() -> None:
    uvicorn.run("shortdrama_pipeline.api:app", host="127.0.0.1", port=8000, reload=False)
