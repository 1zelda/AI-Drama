from __future__ import annotations

import json
from pathlib import Path

import typer
from openai import OpenAI

from shortdrama_pipeline.api import build_runner
from shortdrama_pipeline.config import load_settings
from shortdrama_pipeline.models import JobCreate, JobStatus

app = typer.Typer(help="中文短剧生产流水线")


def _cli_progress(event: str, payload: dict) -> None:
    if event == "character_generation_started":
        typer.echo(f"开始生成人物：{payload['character_name']}（{payload['character_id']}）")
    elif event == "character_generation_completed":
        typer.echo(f"人物已生成：{payload['character_name']}")
        typer.echo(f"本地图片：{payload['approved_path']}")
        typer.echo(f"参考图 URL：{payload['approved_url']}")


def _build_cli_runner():
    runner = build_runner()
    runner.progress_callback = _cli_progress
    return runner


def _show_projects(runner) -> None:
    for project in runner.project_store.list_projects():
        snapshot = runner.project_store.project_snapshot(project.project_id, runner.job_store)
        typer.echo(
            f"{project.project_id}\t{project.title}\tlatest_job={project.latest_job_id}\t"
            f"script={snapshot.script_status}\tcharacter={snapshot.character_status}\tvideo={snapshot.video_status}"
        )


def _choose_from_list(title: str, options: list[tuple[str, str]]) -> str:
    if not options:
        raise typer.BadParameter("没有可选项。")
    typer.echo(title)
    for index, (_, label) in enumerate(options, start=1):
        typer.echo(f"{index}. {label}")
    selected = typer.prompt("请选择编号", type=int)
    if selected < 1 or selected > len(options):
        raise typer.BadParameter("编号超出范围。")
    return options[selected - 1][0]


def _show_project_latest(runner, project_id: str) -> None:
    project = runner.project_store.get_project(project_id)
    latest_dir = runner.artifact_store.project_latest_dir(project_id)
    typer.echo(f"项目：{project.project_id}")
    typer.echo(f"标题：{project.title}")
    typer.echo(f"Latest 目录：{latest_dir}")

    script_path = latest_dir / "script" / "reviewed_script.json"
    characters_path = latest_dir / "characters" / "character_profiles.json"
    typer.echo(f"剧本：{script_path}")
    typer.echo(f"人物：{characters_path}")

    if script_path.exists():
        script = json.loads(script_path.read_text(encoding="utf-8"))
        typer.echo(f"剧名：{script.get('series_title', project.title)}")
        episodes = script.get("episodes", [])
        typer.echo(f"集数：{len(episodes)}")
        if episodes:
            typer.echo(f"最新一集：{episodes[-1].get('title', '')}")

    if characters_path.exists():
        characters = json.loads(characters_path.read_text(encoding="utf-8"))
        names = [character.get("name", "") for character in characters if character.get("name")]
        if names:
            typer.echo(f"人物：{'、'.join(names)}")

    final_videos = sorted(latest_dir.glob("videos/*/final.mp4"))
    if final_videos:
        for video in final_videos:
            typer.echo(f"成片：{video}")
    else:
        typer.echo("成片：暂无")


def _script_quality_report_for_job(runner, job) -> dict | None:
    try:
        runner.artifact_store.register_job_dir(job.job_id, job.artifact_dir)
        return runner.artifact_store.read_json(job.job_id, "harness/script_quality_report.json")
    except (FileNotFoundError, KeyError):
        return None


def _echo_script_quality_summary(report: dict | None) -> None:
    if report is None:
        return
    typer.echo("剧本质检")
    score = report.get("overall_score")
    if score is not None:
        typer.echo(f"- 总评分：{score}")
    summary = report.get("summary")
    if summary:
        typer.echo(f"- 摘要：{summary}")
    episode_warnings = report.get("episode_warnings") or {}
    for episode_id, warnings in list(episode_warnings.items())[:3]:
        for warning in warnings[:2]:
            typer.echo(f"- {episode_id}：{warning}")
    for issue in (report.get("shot_issues") or [])[:3]:
        location = issue.get("episode_id", "")
        if issue.get("shot_id"):
            location = f"{location}/{issue['shot_id']}"
        typer.echo(f"- {location}：预警 {issue.get('title', '')} {issue.get('detail', '')}")


def _project_stage_label(snapshot) -> str:
    status = snapshot.latest_job_status
    if status == JobStatus.SCRIPTING.value:
        return "剧本生成中"
    if status == JobStatus.SCRIPT_REVIEW_PENDING.value:
        return "剧本待审核"
    if status == JobStatus.SCRIPT_APPROVED.value:
        return "剧本已批准"
    if status == JobStatus.CHARACTER_DESIGNING.value:
        return "人物生成中"
    if status == JobStatus.CHARACTER_REVIEW_PENDING.value:
        return "人物待审核"
    if status == JobStatus.CHARACTER_APPROVED.value:
        return "人物已批准"
    if status in {JobStatus.SHOT_PLANNING.value, JobStatus.VIDEO_GENERATING.value, JobStatus.COMPOSING.value}:
        return "视频生成中"
    if status == JobStatus.COMPLETED.value:
        return "已完成"
    if status == JobStatus.FAILED.value:
        return "失败"
    return "未开始"


def _continue_project_run(
    runner,
    project_id: str,
    notes: str = "",
    duration_seconds: int | None = None,
    episode_count: int | None = None,
) -> None:
    project = runner.project_store.get_project(project_id)
    latest_dir = runner.artifact_store.project_latest_dir(project_id)
    has_reusable_assets = (
        (latest_dir / "script" / "reviewed_script.json").exists()
        and (latest_dir / "characters" / "character_profiles.json").exists()
    )
    if not has_reusable_assets:
        raise typer.BadParameter("该项目尚未沉淀已批准的剧本和人物，不能继续生产视频。")
    if project.latest_job_id is not None:
        latest_job = runner.job_store.get_job(project.latest_job_id)
    else:
        jobs = runner.job_store.list_jobs(project_id=project_id)
        if not jobs:
            raise typer.BadParameter("该项目尚未沉淀已批准的剧本和人物，不能继续生产视频。")
        latest_job = jobs[0]
    job = runner.create_job(
        JobCreate(
            topic=project.title,
            duration_seconds=duration_seconds or latest_job.duration_seconds,
            episode_count=episode_count or latest_job.episode_count,
            ratio=latest_job.ratio,
            style=latest_job.style,
            notes=notes,
            project_id=project_id,
        )
    )
    typer.echo(f"任务已创建：{job.job_id}")
    typer.echo(f"项目：{job.project_id}")
    typer.echo(f"状态：{job.status.value}")


def _show_project_dashboard(runner, project_id: str) -> None:
    snapshot = runner.project_store.project_snapshot(project_id, runner.job_store)
    typer.echo(f"项目：{snapshot.project_id}")
    typer.echo(f"标题：{snapshot.title}")
    typer.echo("当前项目状态")
    typer.echo(f"阶段：{_project_stage_label(snapshot)}")
    typer.echo(f"剧本：{snapshot.script_status}")
    typer.echo(f"人物：{snapshot.character_status}")
    typer.echo(f"视频：{snapshot.video_status}")
    typer.echo(f"最新任务：{snapshot.latest_job_id or '暂无'}")
    typer.echo(f"失败任务数：{snapshot.failed_job_count}")
    if snapshot.latest_job_id:
        job = runner.job_store.get_job(snapshot.latest_job_id)
        _echo_script_quality_summary(_script_quality_report_for_job(runner, job))
    typer.echo("下一步建议：")
    if snapshot.script_status == "review_pending":
        typer.echo("- 审核并批准剧本")
    elif snapshot.character_status == "review_pending":
        typer.echo("- 审核并批准人物")
    elif snapshot.video_status == "generating":
        typer.echo("- 等待视频生成完成")
    elif snapshot.video_status == "completed":
        typer.echo("- 查看最新成片")
    else:
        typer.echo("- 创建新任务或继续生产")


def _repair_project_latest_after_failed_cleanup(runner, job) -> None:
    if not job.project_id:
        return
    project = runner.project_store.get_project(job.project_id)
    if project.latest_job_id != job.job_id:
        return
    replacement = next(
        (
            candidate
            for candidate in runner.job_store.list_jobs(project_id=job.project_id)
            if candidate.job_id != job.job_id and candidate.status != JobStatus.FAILED
        ),
        None,
    )
    runner.project_store.set_latest_job(job.project_id, replacement.job_id if replacement else None)


def _cleanup_failed_job(runner, job_id: str) -> None:
    job = runner.job_store.get_job(job_id)
    if job.status != JobStatus.FAILED:
        raise typer.BadParameter(f"只能清理 failed 任务，当前状态为：{job.status.value}")
    trash_path = runner.artifact_store.soft_delete_job(job_id)
    _repair_project_latest_after_failed_cleanup(runner, job)
    runner.job_store.delete_job(job_id)
    typer.echo(f"已软删除失败任务：{job_id}")
    typer.echo(f"回收站目录：{trash_path}")


def _retry_failed_job(runner, job_id: str, notes: str = "") -> None:
    failed_job = runner.job_store.get_job(job_id)
    if failed_job.status != JobStatus.FAILED:
        raise typer.BadParameter(f"只能重试 failed 任务，当前状态为：{failed_job.status.value}")
    job = runner.create_job(
        JobCreate(
            topic=failed_job.topic,
            duration_seconds=failed_job.duration_seconds,
            episode_count=failed_job.episode_count,
            ratio=failed_job.ratio,
            style=failed_job.style,
            notes=notes or failed_job.notes,
            project_id=failed_job.project_id,
        )
    )
    typer.echo(f"任务已重试：{job.job_id}")
    typer.echo(f"项目：{job.project_id}")
    typer.echo(f"状态：{job.status.value}")


def _latest_job_id(runner) -> str:
    jobs = runner.job_store.list_jobs()
    if not jobs:
        raise typer.BadParameter("当前还没有任务记录。")
    return jobs[0].job_id


def _prompt_job_id(runner, label: str = "请输入 job_id") -> str:
    job_id = typer.prompt(label, default="").strip()
    return job_id or _latest_job_id(runner)


def _select_job_id(runner, title: str = "请选择任务") -> str:
    jobs = runner.job_store.list_jobs()
    return _choose_from_list(
        title,
        [(job.job_id, f"{job.job_id} | {job.status.value} | {job.topic}") for job in jobs],
    )


def _select_project_id(runner, title: str = "请选择项目") -> str:
    projects = runner.project_store.list_projects()
    return _choose_from_list(
        title,
        [(project.project_id, f"{project.project_id} | {project.title}") for project in projects],
    )


def _create_run_interactive(runner) -> None:
    topic = typer.prompt("请输入短剧主题").strip()
    duration_seconds = typer.prompt("请输入时长（秒）", type=int)
    episode_count = typer.prompt("请输入集数", type=int)
    ratio = typer.prompt("请输入画幅比例", default="9:16").strip() or "9:16"
    style = typer.prompt("请输入风格描述", default="竖屏短剧，强反转，真实影视感").strip() or "竖屏短剧，强反转，真实影视感"
    notes = typer.prompt("请输入额外说明", default="")
    job = runner.create_job(
        JobCreate(
            topic=topic,
            duration_seconds=duration_seconds,
            episode_count=episode_count,
            ratio=ratio,
            style=style,
            notes=notes,
        )
    )
    typer.echo(f"任务已创建：{job.job_id}")
    typer.echo(f"项目：{job.project_id}")
    typer.echo(f"状态：{job.status.value}")


def _handle_shell_action(action) -> None:
    try:
        action()
    except Exception as exc:
        typer.echo(f"执行失败：{exc}")


@app.command("create")
def create(
    topic: str | None = typer.Option(None, help="短剧主题"),
    duration_seconds: int | None = typer.Option(None, help="单次生产总时长（秒）"),
    episode_count: int | None = typer.Option(None, help="集数"),
    ratio: str = typer.Option("9:16", help="画幅比例"),
    style: str = typer.Option("竖屏短剧，强反转，真实影视感", help="风格描述"),
    notes: str = typer.Option("", help="额外说明"),
) -> None:
    """交互式创建短剧生产任务。"""
    runner = _build_cli_runner()
    if topic is None:
        topic = typer.prompt("请输入短剧主题")
    if duration_seconds is None:
        duration_seconds = typer.prompt("请输入时长（秒）", type=int)
    if episode_count is None:
        episode_count = typer.prompt("请输入集数", type=int)
    job = runner.create_job(
        JobCreate(
            topic=topic,
            duration_seconds=duration_seconds,
            episode_count=episode_count,
            ratio=ratio,
            style=style,
            notes=notes,
        )
    )
    typer.echo(f"任务已创建：{job.job_id}")
    typer.echo(f"项目：{job.project_id}")
    typer.echo(f"状态：{job.status.value}")


@app.command("projects")
def projects() -> None:
    """列出项目。"""
    runner = _build_cli_runner()
    _show_projects(runner)


@app.command("project-latest")
def project_latest(project_id: str) -> None:
    """查看项目 latest 目录中的最近产物。"""
    runner = _build_cli_runner()
    _show_project_latest(runner, project_id)


@app.command("project-dashboard")
def project_dashboard(project_id: str) -> None:
    """查看项目当前状态与下一步建议。"""
    runner = _build_cli_runner()
    _show_project_dashboard(runner, project_id)


@app.command("jobs")
def jobs() -> None:
    """列出任务。"""
    runner = _build_cli_runner()
    for job in runner.job_store.list_jobs():
        typer.echo(f"{job.job_id}\t{job.status.value}\t{job.topic}")


@app.command("status")
def status(job_id: str) -> None:
    """查看任务状态。"""
    runner = _build_cli_runner()
    job = runner.job_store.get_job(job_id)
    typer.echo(f"任务：{job.job_id}")
    typer.echo(f"状态：{job.status.value}")
    typer.echo(f"主题：{job.topic}")
    typer.echo(f"目录：{job.artifact_dir}")


@app.command("review")
def review(job_id: str) -> None:
    """根据当前状态进入轻量审核提示。"""
    runner = _build_cli_runner()
    job = runner.job_store.get_job(job_id)
    typer.echo(f"任务：{job.job_id}")
    typer.echo(f"状态：{job.status.value}")
    if job.status.value == "script_review_pending":
        _echo_script_quality_summary(_script_quality_report_for_job(runner, job))
        typer.echo("1. 查看剧本摘要")
        typer.echo("2. 打开剧本 JSON")
        typer.echo("3. 重新生成剧本")
        typer.echo("4. 批准剧本并继续")
        typer.echo("5. 退出")
    elif job.status.value == "character_review_pending":
        typer.echo("1. 查看人物档案")
        typer.echo("2. 打开人物图片目录")
        typer.echo("3. 重新生成某个角色")
        typer.echo("4. 指定本地参考图")
        typer.echo("5. 批准人物并继续")
        typer.echo("6. 退出")
    else:
        typer.echo("当前状态没有待人工审核的内容。")


@app.command("continue")
def continue_job(job_id: str) -> None:
    """继续当前审核后的流水线。"""
    runner = _build_cli_runner()
    job = runner.continue_job(job_id)
    typer.echo(f"状态：{job.status.value}")


@app.command("reject-script")
def reject_script(job_id: str, reason: str = typer.Option(..., help="拒绝原因")) -> None:
    runner = _build_cli_runner()
    job = runner.reject_script(job_id, reason)
    typer.echo(f"状态：{job.status.value}")


@app.command("regenerate-script")
def regenerate_script(job_id: str, notes: str = typer.Option("", help="重生要求")) -> None:
    runner = _build_cli_runner()
    job = runner.regenerate_script(job_id, notes=notes)
    typer.echo(f"状态：{job.status.value}")


@app.command("reject-characters")
def reject_characters(job_id: str, reason: str = typer.Option(..., help="拒绝原因")) -> None:
    runner = _build_cli_runner()
    job = runner.reject_characters(job_id, reason)
    typer.echo(f"状态：{job.status.value}")


@app.command("regenerate-character")
def regenerate_character(job_id: str, character_id: str) -> None:
    runner = _build_cli_runner()
    job = runner.regenerate_character(job_id, character_id)
    typer.echo(f"状态：{job.status.value}")


@app.command("continue-project")
def continue_project(
    project_id: str,
    notes: str = typer.Option("", help="本次续生产备注"),
    duration_seconds: int | None = typer.Option(None, help="本次时长，默认沿用最近一次任务"),
    episode_count: int | None = typer.Option(None, help="本次数量，默认沿用最近一次任务"),
) -> None:
    """沿用已有项目最近一次已批准剧本和人物，继续生产新 run。"""
    runner = _build_cli_runner()
    _continue_project_run(runner, project_id, notes=notes, duration_seconds=duration_seconds, episode_count=episode_count)


@app.command("cleanup-failed")
def cleanup_failed(job_id: str) -> None:
    """软删除失败任务并移入回收站目录。"""
    runner = _build_cli_runner()
    _cleanup_failed_job(runner, job_id)


@app.command("retry-failed")
def retry_failed(
    job_id: str,
    notes: str = typer.Option("", help="本次重试备注，默认沿用失败任务备注"),
) -> None:
    """基于失败任务所属项目重新开一个新 run。"""
    runner = _build_cli_runner()
    _retry_failed_job(runner, job_id, notes=notes)


@app.command("shell")
def shell() -> None:
    """进入轻量交互菜单。"""
    runner = _build_cli_runner()
    while True:
        typer.echo("交互菜单")
        typer.echo("1. 创建新项目/新任务")
        typer.echo("2. 列出项目")
        typer.echo("3. 查看项目 latest")
        typer.echo("4. 按项目继续生产")
        typer.echo("5. 列出任务")
        typer.echo("6. 查看任务状态")
        typer.echo("7. 审核任务")
        typer.echo("8. 批准剧本")
        typer.echo("9. 批准人物")
        typer.echo("10. 打开任务目录")
        typer.echo("11. 软删除失败任务")
        typer.echo("12. 重试失败任务")
        typer.echo("13. 项目工作台")
        typer.echo("14. 查看失败任务摘要")
        typer.echo("0. 退出")
        choice = typer.prompt("请选择", default="0").strip()
        if choice == "0":
            typer.echo("已退出")
            return
        if choice == "1":
            _handle_shell_action(lambda: _create_run_interactive(runner))
            continue
        if choice == "2":
            _handle_shell_action(lambda: _show_projects(runner))
            continue
        if choice == "3":
            project_id = _select_project_id(runner)
            _handle_shell_action(lambda: _show_project_latest(runner, project_id))
            continue
        if choice == "4":
            project_id = _select_project_id(runner)
            notes = typer.prompt("请输入备注", default="")
            _handle_shell_action(lambda: _continue_project_run(runner, project_id, notes=notes))
            continue
        if choice == "5":
            _handle_shell_action(lambda: [typer.echo(f"{job.job_id}\t{job.status.value}\t{job.topic}") for job in runner.job_store.list_jobs()])
            continue
        if choice == "6":
            def show_status():
                job_id = _select_job_id(runner)
                job = runner.job_store.get_job(job_id)
                typer.echo(f"任务：{job.job_id}")
                typer.echo(f"状态：{job.status.value}")
                typer.echo(f"主题：{job.topic}")
                typer.echo(f"目录：{job.artifact_dir}")

            _handle_shell_action(show_status)
            continue
        if choice == "7":
            def review_job():
                job_id = _select_job_id(runner)
                job = runner.job_store.get_job(job_id)
                typer.echo(f"任务：{job.job_id}")
                typer.echo(f"状态：{job.status.value}")
                if job.status.value == "script_review_pending":
                    typer.echo("1. 查看剧本摘要")
                    typer.echo("2. 打开剧本 JSON")
                    typer.echo("3. 重新生成剧本")
                    typer.echo("4. 批准剧本并继续")
                    typer.echo("5. 退出")
                elif job.status.value == "character_review_pending":
                    typer.echo("1. 查看人物档案")
                    typer.echo("2. 打开人物图片目录")
                    typer.echo("3. 重新生成某个角色")
                    typer.echo("4. 指定本地参考图")
                    typer.echo("5. 批准人物并继续")
                    typer.echo("6. 退出")
                else:
                    typer.echo("当前状态没有待人工审核的内容。")

            _handle_shell_action(review_job)
            continue
        if choice == "8":
            def approve_script_in_shell():
                job_id = _select_job_id(runner)
                job = runner.approve_script(job_id)
                typer.echo(f"状态：{job.status.value}")

            _handle_shell_action(approve_script_in_shell)
            continue
        if choice == "9":
            def approve_characters_in_shell():
                job_id = _select_job_id(runner)
                job = runner.approve_characters(job_id)
                typer.echo(f"状态：{job.status.value}")

            _handle_shell_action(approve_characters_in_shell)
            continue
        if choice == "10":
            def open_job_in_shell():
                job_id = _select_job_id(runner)
                job = runner.job_store.get_job(job_id)
                typer.echo(str(Path(job.artifact_dir).resolve()))

            _handle_shell_action(open_job_in_shell)
            continue
        if choice == "11":
            def cleanup_failed_in_shell():
                job_id = _select_job_id(runner, "请选择失败任务")
                _cleanup_failed_job(runner, job_id)

            _handle_shell_action(cleanup_failed_in_shell)
            continue
        if choice == "12":
            def retry_failed_in_shell():
                job_id = _select_job_id(runner, "请选择失败任务")
                notes = typer.prompt("请输入重试备注", default="")
                _retry_failed_job(runner, job_id, notes=notes)

            _handle_shell_action(retry_failed_in_shell)
            continue
        if choice == "13":
            def project_dashboard_in_shell():
                project_id = _select_project_id(runner)
                _show_project_dashboard(runner, project_id)

            _handle_shell_action(project_dashboard_in_shell)
            continue
        if choice == "14":
            def failed_summary_in_shell():
                job_id = _select_job_id(runner, "请选择失败任务")
                _show_failed_summary(runner, job_id)

            _handle_shell_action(failed_summary_in_shell)
            continue
        typer.echo("无效选项，请重新输入。")


@app.command("open")
def open_job(job_id: str) -> None:
    """输出任务目录路径。"""
    runner = _build_cli_runner()
    job = runner.job_store.get_job(job_id)
    typer.echo(str(Path(job.artifact_dir).resolve()))


@app.command("approve-script")
def approve_script(job_id: str) -> None:
    """批准剧本并进入人物生成。"""
    runner = _build_cli_runner()
    job = runner.approve_script(job_id)
    typer.echo(f"状态：{job.status.value}")


@app.command("approve-characters")
def approve_characters(job_id: str) -> None:
    """批准人物形象并继续生成视频。"""
    runner = _build_cli_runner()
    job = runner.approve_characters(job_id)
    typer.echo(f"状态：{job.status.value}")


def _show_failed_summary(runner, job_id: str) -> None:
    job = runner.job_store.get_job(job_id)
    typer.echo(f"任务：{job.job_id}")
    typer.echo(f"失败阶段：{job.failed_phase}")
    typer.echo(f"错误：{job.last_error}")
    log_path = Path(job.artifact_dir) / "logs" / "model_calls.jsonl"
    typer.echo(f"日志：{log_path}")
    if log_path.exists():
        entries = [json.loads(line) for line in log_path.read_text(encoding='utf-8').splitlines() if line.strip()]
        failed = next((entry for entry in reversed(entries) if str(entry.get("operation", "")).endswith("_failed")), None)
        if failed:
            typer.echo(f"响应状态：{failed.get('response_status')}")
            typer.echo(f"响应体：{failed.get('response_body')}")
            typer.echo(f"payload_summary：{failed.get('payload_summary')}")


@app.command("failed-summary")
def failed_summary(job_id: str) -> None:
    """查看失败任务的错误摘要。"""
    runner = _build_cli_runner()
    _show_failed_summary(runner, job_id)


@app.command("config")
def config() -> None:
    """查看本地配置。"""
    settings = load_settings()
    typer.echo(f"输出目录：{settings.output_dir}")
    typer.echo(f"数据库：{settings.db_path}")
    typer.echo(f"Ark Base URL：{settings.ark_base_url}")
    typer.echo(f"Provider 模式：{settings.provider_mode}")
    typer.echo(f"Seedance 并发：{settings.seedance_concurrency}")


@app.command("smoke-ark")
def smoke_ark() -> None:
    """测试 Ark 线上文本模型连通性。"""
    settings = load_settings()
    if not settings.ark_api_key:
        typer.echo("缺少 ARK_API_KEY。请通过环境变量或项目 .env 配置。", err=True)
        raise typer.Exit(code=1)

    client = OpenAI(base_url=settings.ark_base_url, api_key=settings.ark_api_key)
    response = client.responses.create(
        model=settings.seed_model,
        input=[
            {
                "role": "user",
                "content": [{"type": "input_text", "text": "请只回复：中文短剧流水线连通成功"}],
            }
        ],
    )
    typer.echo(response.output_text.strip())
