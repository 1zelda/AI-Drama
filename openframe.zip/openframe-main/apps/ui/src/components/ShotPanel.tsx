import { useMemo, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { PhotoView } from 'react-photo-view'
import { Camera, Clapperboard, PlusCircle, Sparkles, Trash2, X } from 'lucide-react'

type SceneOption = { id: string; title: string }
type CharacterOption = { id: string; name: string }
type PropOption = { id: string; name: string }
type CostumeOption = { id: string; name: string; character_ids: string[] }

export type ShotDraft = {
  scene_id: string
  title: string
  shot_size: string
  camera_angle: string
  camera_move: string
  duration_sec: number
  action: string
  dialogue: string
  character_ids: string[]
  prop_ids: string[]
  costume_ids: string[]
}

export type ShotCard = ShotDraft & {
  id: string
  series_id: string
  shot_index: number
  thumbnail: string | null
  production_first_frame: string | null
  production_last_frame: string | null
  production_video: string | null
  production_first_frame_prompt_override: string | null
  production_last_frame_prompt_override: string | null
  production_video_prompt_override: string | null
  created_at: number
}

interface ShotPanelProps {
  shots: ShotCard[]
  scenes: SceneOption[]
  characters: CharacterOption[]
  props: PropOption[]
  costumes: CostumeOption[]
  projectRatio?: '16:9' | '9:16'
  generatingFromScript: boolean
  generatingAllImages: boolean
  generatingShotId: string | null
  onAddShot: (draft: ShotDraft) => void
  onUpdateShot: (id: string, draft: ShotDraft) => void
  onDeleteShot: (id: string, title: string) => void
  onGenerateFromScript: (targetCount: number) => void
  onGenerateAllImages: () => void
  onGenerateSingleImage: (id: string) => void
}

const emptyDraft: ShotDraft = {
  scene_id: '',
  title: '',
  shot_size: '',
  camera_angle: '',
  camera_move: '',
  duration_sec: 3,
  action: '',
  dialogue: '',
  character_ids: [],
  prop_ids: [],
  costume_ids: [],
}

function getThumbnailSrc(value: string | null): string | null {
  if (!value) return null
  if (/^(https?:|data:|blob:|openframe-thumb:)/i.test(value)) return value
  return `openframe-thumb://local?path=${encodeURIComponent(value)}`
}

export function ShotPanel({
  shots,
  scenes,
  characters,
  props,
  costumes,
  projectRatio = '16:9',
  generatingFromScript,
  generatingAllImages,
  generatingShotId,
  onAddShot,
  onUpdateShot,
  onDeleteShot,
  onGenerateFromScript,
  onGenerateAllImages,
  onGenerateSingleImage,
}: ShotPanelProps) {
  const { t } = useTranslation()
  const mediaAspectClass = projectRatio === '9:16' ? 'aspect-[9/16]' : 'aspect-video'
  const [editingId, setEditingId] = useState<string | null>(null)
  const [targetShotCountInput, setTargetShotCountInput] = useState('20')
  const [open, setOpen] = useState(false)
  const [error, setError] = useState('')
  const [draft, setDraft] = useState<ShotDraft>(emptyDraft)

  const targetShotCount = (() => {
    const value = Number(targetShotCountInput)
    if (!Number.isFinite(value)) return 20
    return Math.max(1, Math.min(200, Math.round(value)))
  })()

  const sceneNameMap = useMemo(() => {
    const map = new Map<string, string>()
    for (const scene of scenes) map.set(scene.id, scene.title)
    return map
  }, [scenes])

  const characterNameMap = useMemo(() => {
    const map = new Map<string, string>()
    for (const c of characters) map.set(c.id, c.name)
    return map
  }, [characters])

  const propNameMap = useMemo(() => {
    const map = new Map<string, string>()
    for (const item of props) map.set(item.id, item.name)
    return map
  }, [props])

  const costumeNameMap = useMemo(() => {
    const map = new Map<string, string>()
    for (const item of costumes) map.set(item.id, item.name)
    return map
  }, [costumes])

  const selectableCostumes = useMemo(() => {
    if (draft.character_ids.length === 0) return []
    const selectedCharacterIdSet = new Set(draft.character_ids)
    return costumes.filter((item) =>
      draft.costume_ids.includes(item.id)
      || item.character_ids.some((characterId) => selectedCharacterIdSet.has(characterId)))
  }, [costumes, draft.character_ids, draft.costume_ids])

  function openCreate() {
    setEditingId(null)
    setDraft({ ...emptyDraft, scene_id: scenes[0]?.id ?? '' })
    setError('')
    setOpen(true)
  }

  function openEdit(card: ShotCard) {
    setEditingId(card.id)
    setDraft({
      scene_id: card.scene_id,
      title: card.title,
      shot_size: card.shot_size,
      camera_angle: card.camera_angle,
      camera_move: card.camera_move,
      duration_sec: card.duration_sec,
      action: card.action,
      dialogue: card.dialogue,
      character_ids: card.character_ids,
      prop_ids: card.prop_ids,
      costume_ids: card.costume_ids,
    })
    setError('')
    setOpen(true)
  }

  function submit() {
    if (!draft.scene_id) {
      setError(t('projectLibrary.shotSceneRequired'))
      return
    }
    if (!draft.title.trim()) {
      setError(t('projectLibrary.shotTitleRequired'))
      return
    }

    const selectedCharacterIdSet = new Set(draft.character_ids)
    const allowedCostumeIdSet = new Set(
      costumes
        .filter((item) => item.character_ids.some((characterId) => selectedCharacterIdSet.has(characterId)))
        .map((item) => item.id),
    )
    const payload: ShotDraft = {
      ...draft,
      title: draft.title.trim(),
      shot_size: draft.shot_size.trim(),
      camera_angle: draft.camera_angle.trim(),
      camera_move: draft.camera_move.trim(),
      action: draft.action.trim(),
      dialogue: draft.dialogue.trim(),
      duration_sec: Number.isFinite(draft.duration_sec) ? Math.max(1, draft.duration_sec) : 3,
      costume_ids: draft.costume_ids.filter((id) => allowedCostumeIdSet.has(id)),
    }

    if (editingId) onUpdateShot(editingId, payload)
    else onAddShot(payload)
    setOpen(false)
  }

  return (
    <section className="h-full rounded-2xl border border-base-300 bg-linear-to-br from-base-200/30 via-base-100 to-base-200/20 text-base-content p-4 md:p-5 flex flex-col gap-4">
      <div className="flex items-start justify-between gap-3">
        <div>
          <h2 className="text-lg font-semibold tracking-wide">{t('projectLibrary.shotPanelTitle')}</h2>
          <p className="text-xs text-base-content/60 mt-1">{t('projectLibrary.shotPanelSubtitle')}</p>
        </div>
        <div className="flex flex-col items-end gap-1">
          <div className="flex items-center gap-2">
            <label className="input input-sm input-bordered flex items-center gap-2 w-32">
              <span className="text-[11px] text-base-content/60 whitespace-nowrap">
                {t('projectLibrary.shotTargetCountLabel')}
              </span>
              <input
                type="number"
                min={1}
                max={200}
                className="w-full bg-transparent outline-none text-right"
                value={targetShotCountInput}
                onChange={(event) => setTargetShotCountInput(event.target.value)}
                onBlur={() => setTargetShotCountInput(String(targetShotCount))}
              />
            </label>
            <button
              type="button"
              className="btn btn-sm btn-outline"
              onClick={() => onGenerateFromScript(targetShotCount)}
              disabled={generatingAllImages || generatingFromScript}
            >
              <Camera size={12} />
              {generatingFromScript ? t('projectLibrary.aiStreaming') : t('projectLibrary.shotGenerateFromScript')}
            </button>
            <button
              type="button"
              className="btn btn-sm btn-outline"
              onClick={onGenerateAllImages}
              disabled={generatingAllImages || generatingFromScript}
            >
              <Clapperboard size={12} />
              {generatingAllImages ? t('projectLibrary.aiStreaming') : t('projectLibrary.shotGenerateAllImages')}
            </button>
          </div>
        </div>
      </div>

      <div className="flex-1 min-h-0 overflow-y-auto overflow-x-hidden">
        <div className="grid grid-cols-[repeat(auto-fill,minmax(14rem,1fr))] items-start gap-3 pr-2">
          <article className="w-full rounded-xl border border-dashed border-base-300 bg-base-100/70 flex min-h-40 flex-col items-center justify-center gap-3 px-4 py-6 text-base-content/75 cursor-pointer hover:border-primary/40 hover:bg-base-100 transition-colors" onClick={openCreate}>
            <PlusCircle size={24} className="text-base-content/55" />
            <p className="text-sm font-medium">{t('projectLibrary.shotSetup')}</p>
          </article>

          {shots.map((shot) => (
            <article key={shot.id} className="w-full rounded-xl border border-base-300 bg-base-100 overflow-hidden flex flex-col cursor-pointer hover:shadow-md transition-shadow" onClick={() => openEdit(shot)}>
              {(() => {
                const thumbnailSrc = getThumbnailSrc(shot.thumbnail)
                if (!thumbnailSrc) {
                  return (
                    <button
                      type="button"
                      className={`${mediaAspectClass} border-b border-base-300 bg-linear-to-b from-base-200 via-base-100 to-base-200/70 flex items-center justify-center w-full`}
                      onClick={(event) => {
                        event.preventDefault()
                        event.stopPropagation()
                      }}
                    >
                      <Clapperboard size={28} className="text-base-content/60" />
                    </button>
                  )
                }
                return (
                  <PhotoView src={thumbnailSrc}>
                    <button
                      type="button"
                      className={`${mediaAspectClass} border-b border-base-300 bg-linear-to-b from-base-200 via-base-100 to-base-200/70 flex items-center justify-center w-full`}
                      onClick={(event) => {
                        event.stopPropagation()
                      }}
                    >
                      <img src={thumbnailSrc} alt={shot.title} className="h-full w-full object-cover" />
                    </button>
                  </PhotoView>
                )
              })()}
              <div className="p-3 flex flex-col">
                <p className="text-sm font-semibold line-clamp-1">#{shot.shot_index} {shot.title}</p>
                <p className="mt-1 text-xs text-base-content/65 line-clamp-1">{sceneNameMap.get(shot.scene_id) || t('projectLibrary.sceneCardUntitled')}</p>
                <p className="mt-2 text-xs text-base-content/65 line-clamp-1">{[shot.shot_size, shot.camera_angle, shot.camera_move].filter(Boolean).join(' · ') || '-'}</p>
                <p className="mt-2 text-xs text-base-content/65 line-clamp-4">{shot.action || '-'}</p>
                <div className="mt-2 flex flex-wrap gap-1">
                  {shot.character_ids.slice(0, 3).map((id) => (
                    <span key={id} className="badge badge-sm badge-outline">{characterNameMap.get(id) || '?'}</span>
                  ))}
                </div>
                <div className="mt-1 flex flex-wrap gap-1">
                  {shot.prop_ids.slice(0, 3).map((id) => (
                    <span key={id} className="badge badge-sm badge-ghost">{propNameMap.get(id) || '?'}</span>
                  ))}
                </div>
                <div className="mt-1 flex flex-wrap gap-1">
                  {shot.costume_ids.slice(0, 3).map((id) => (
                    <span key={id} className="badge badge-sm badge-secondary badge-outline">{costumeNameMap.get(id) || '?'}</span>
                  ))}
                </div>
                <div className="mt-3 pt-3 border-t border-base-300 flex justify-center gap-1">
                  <button
                    type="button"
                    className="btn btn-xs btn-outline"
                    onClick={(event) => {
                      event.preventDefault()
                      event.stopPropagation()
                      onGenerateSingleImage(shot.id)
                    }}
                    disabled={generatingFromScript || generatingAllImages || generatingShotId === shot.id}
                    title={t('projectLibrary.shotGenerateSingleImage')}
                  >
                    <Sparkles size={12} />
                  </button>
                  <button
                    type="button"
                    className="btn btn-xs btn-outline text-error border-error/40 hover:bg-error/10"
                    onClick={(event) => {
                      event.preventDefault()
                      event.stopPropagation()
                      onDeleteShot(shot.id, shot.title)
                    }}
                    title={t('projectLibrary.delete')}
                  >
                    <Trash2 size={12} />
                  </button>
                </div>
              </div>
            </article>
          ))}
        </div>
      </div>

      {open ? (
        <div className="fixed inset-0 z-40 flex items-center justify-center p-4">
          <button type="button" className="absolute inset-0 bg-base-content/35" onClick={() => setOpen(false)} />
          <article className="relative z-10 w-full max-w-3xl rounded-2xl border border-base-300 bg-base-100 shadow-2xl overflow-hidden">
            <div className="border-b border-base-300 bg-base-100 px-5 py-4 md:px-6 flex items-center justify-between">
              <h3 className="text-xl font-semibold">{editingId ? t('projectLibrary.shotEditTitle') : t('projectLibrary.shotCreateTitle')}</h3>
              <button type="button" className="btn btn-sm btn-ghost btn-circle" onClick={() => setOpen(false)}><X size={16} /></button>
            </div>

            <div className="p-5 md:p-6 max-h-[70vh] overflow-auto grid grid-cols-1 md:grid-cols-2 gap-3">
              <label className="form-control flex flex-col items-start gap-1 md:col-span-2">
                <span className="text-sm font-medium text-base-content/75">{t('projectLibrary.shotSceneLabel')}</span>
                <select className="select select-bordered w-full" value={draft.scene_id} onChange={(e) => setDraft((p) => ({ ...p, scene_id: e.target.value }))}>
                  <option value="">{t('projectLibrary.shotScenePlaceholder')}</option>
                  {scenes.map((scene) => <option key={scene.id} value={scene.id}>{scene.title || t('projectLibrary.sceneCardUntitled')}</option>)}
                </select>
              </label>

              <label className="form-control flex flex-col items-start gap-1 md:col-span-2">
                <span className="text-sm font-medium text-base-content/75">{t('projectLibrary.shotTitleLabel')}</span>
                <input className="input input-bordered w-full" placeholder={t('projectLibrary.shotTitlePlaceholder')} value={draft.title} onChange={(e) => setDraft((p) => ({ ...p, title: e.target.value }))} />
              </label>

              <label className="form-control flex flex-col items-start gap-1">
                <span className="text-sm font-medium text-base-content/75">{t('projectLibrary.shotSizeLabel')}</span>
                <input className="input input-bordered w-full" placeholder={t('projectLibrary.shotSizePlaceholder')} value={draft.shot_size} onChange={(e) => setDraft((p) => ({ ...p, shot_size: e.target.value }))} />
              </label>

              <label className="form-control flex flex-col items-start gap-1">
                <span className="text-sm font-medium text-base-content/75">{t('projectLibrary.shotDurationLabel')}</span>
                <input type="number" min={1} className="input input-bordered w-full" value={draft.duration_sec} onChange={(e) => setDraft((p) => ({ ...p, duration_sec: Number(e.target.value || 1) }))} />
              </label>

              <label className="form-control flex flex-col items-start gap-1">
                <span className="text-sm font-medium text-base-content/75">{t('projectLibrary.shotAngleLabel')}</span>
                <input className="input input-bordered w-full" placeholder={t('projectLibrary.shotAnglePlaceholder')} value={draft.camera_angle} onChange={(e) => setDraft((p) => ({ ...p, camera_angle: e.target.value }))} />
              </label>

              <label className="form-control flex flex-col items-start gap-1">
                <span className="text-sm font-medium text-base-content/75">{t('projectLibrary.shotMoveLabel')}</span>
                <input className="input input-bordered w-full" placeholder={t('projectLibrary.shotMovePlaceholder')} value={draft.camera_move} onChange={(e) => setDraft((p) => ({ ...p, camera_move: e.target.value }))} />
              </label>

              <label className="form-control flex flex-col items-start gap-1 md:col-span-2">
                <span className="text-sm font-medium text-base-content/75">{t('projectLibrary.shotActionLabel')}</span>
                <textarea className="textarea textarea-bordered min-h-20 w-full" placeholder={t('projectLibrary.shotActionPlaceholder')} value={draft.action} onChange={(e) => setDraft((p) => ({ ...p, action: e.target.value }))} />
              </label>

              <label className="form-control flex flex-col items-start gap-1 md:col-span-2">
                <span className="text-sm font-medium text-base-content/75">{t('projectLibrary.shotDialogueLabel')}</span>
                <textarea className="textarea textarea-bordered min-h-20 w-full" placeholder={t('projectLibrary.shotDialoguePlaceholder')} value={draft.dialogue} onChange={(e) => setDraft((p) => ({ ...p, dialogue: e.target.value }))} />
              </label>

              <div className="form-control flex flex-col items-start gap-1 md:col-span-2">
                <span className="text-sm font-medium text-base-content/75">{t('projectLibrary.shotCharactersLabel')}</span>
                <div className="w-full rounded-lg border border-base-300 p-2 max-h-40 overflow-auto flex flex-wrap gap-2">
                  {characters.map((c) => {
                    const checked = draft.character_ids.includes(c.id)
                    return (
                      <label key={c.id} className="label cursor-pointer gap-2 rounded-md border border-base-300 px-2 py-1">
                        <input
                          type="checkbox"
                          className="checkbox checkbox-xs"
                          checked={checked}
                          onChange={(e) => {
                            setDraft((p) => {
                              const nextCharacterIds = e.target.checked
                                ? [...p.character_ids, c.id]
                                : p.character_ids.filter((id) => id !== c.id)
                              const nextCharacterIdSet = new Set(nextCharacterIds)
                              const nextCostumeIds = p.costume_ids.filter((costumeId) =>
                                costumes.some((item) =>
                                  item.id === costumeId
                                  && item.character_ids.some((characterId) => nextCharacterIdSet.has(characterId))))
                              return {
                                ...p,
                                character_ids: nextCharacterIds,
                                costume_ids: nextCostumeIds,
                              }
                            })
                          }}
                        />
                        <span className="text-xs">{c.name}</span>
                      </label>
                    )
                  })}
                </div>
              </div>

              <div className="form-control flex flex-col items-start gap-1 md:col-span-2">
                <span className="text-sm font-medium text-base-content/75">{t('projectLibrary.shotPropsLabel')}</span>
                <div className="w-full rounded-lg border border-base-300 p-2 max-h-40 overflow-auto flex flex-wrap gap-2">
                  {props.map((item) => {
                    const checked = draft.prop_ids.includes(item.id)
                    return (
                      <label key={item.id} className="label cursor-pointer gap-2 rounded-md border border-base-300 px-2 py-1">
                        <input
                          type="checkbox"
                          className="checkbox checkbox-xs"
                          checked={checked}
                          onChange={(e) => {
                            setDraft((p) => ({
                              ...p,
                              prop_ids: e.target.checked ? [...p.prop_ids, item.id] : p.prop_ids.filter((id) => id !== item.id),
                            }))
                          }}
                        />
                        <span className="text-xs">{item.name}</span>
                      </label>
                    )
                  })}
                </div>
              </div>

              <div className="form-control flex flex-col items-start gap-1 md:col-span-2">
                <span className="text-sm font-medium text-base-content/75">{t('projectLibrary.shotCostumesLabel')}</span>
                <div className="w-full rounded-lg border border-base-300 p-2 max-h-40 overflow-auto flex flex-wrap gap-2">
                  {selectableCostumes.length === 0 ? (
                    <p className="text-xs text-base-content/60">{t('projectLibrary.shotCostumesEmpty')}</p>
                  ) : selectableCostumes.map((item) => {
                    const checked = draft.costume_ids.includes(item.id)
                    return (
                      <label key={item.id} className="label cursor-pointer gap-2 rounded-md border border-base-300 px-2 py-1">
                        <input
                          type="checkbox"
                          className="checkbox checkbox-xs"
                          checked={checked}
                          onChange={(e) => {
                            setDraft((p) => ({
                              ...p,
                              costume_ids: e.target.checked ? [...p.costume_ids, item.id] : p.costume_ids.filter((id) => id !== item.id),
                            }))
                          }}
                        />
                        <span className="text-xs">{item.name}</span>
                      </label>
                    )
                  })}
                </div>
              </div>

              {error ? <p className="text-error text-xs md:col-span-2">{error}</p> : null}
            </div>

            <div className="border-t border-base-300 bg-base-100 px-5 py-3 md:px-6 flex items-center justify-end gap-2">
              <button type="button" className="btn btn-sm btn-ghost" onClick={() => setOpen(false)}>{t('projectLibrary.shotCreateCancel')}</button>
              <button type="button" className="btn btn-sm btn-primary" onClick={submit}>{editingId ? t('projectLibrary.shotUpdateConfirm') : t('projectLibrary.shotCreateConfirm')}</button>
            </div>
          </article>
        </div>
      ) : null}

    </section>
  )
}
