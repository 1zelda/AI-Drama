"""Mock API Django app."""
